<?php $__env->startSection('title', __('sale.products')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->get('sale.products'); ?>
        <small><?php echo app('translator')->get('lang_v1.manage_products'); ?></small>
        <input type="hidden" id="business_id" value="<?php echo e($business_id, false); ?>">
    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
    </ol> -->
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('type', __('product.product_type') . ':'); ?>

                    <?php echo Form::select('type', ['single' => __('lang_v1.single'), 'variable' => __('lang_v1.variable')],
                    null, [
                    'class' => 'form-control select2',
                    'style' => 'width:100%',
                    'id' => 'product_list_filter_type',
                    'placeholder' => __('lang_v1.all'),
                    ]); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('category_id', __('product.category') . ':'); ?>

                    <?php echo Form::select('category_id', $categories, $categoryID_filter, [
                    'class' => 'form-control select2',
                    'style' => 'width:100%',
                    'id' => 'product_list_filter_category_id',
                    'placeholder' => __('lang_v1.all'),
                    ]); ?>

                </div>
            </div>

            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('unit_id', __('product.unit') . ':'); ?>

                    <?php echo Form::select('unit_id', $units, null, [
                    'class' => 'form-control select2',
                    'style' => 'width:100%',
                    'id' => 'product_list_filter_unit_id',
                    'placeholder' => __('lang_v1.all'),
                    ]); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('tax_id', __('product.tax') . ':'); ?>

                    <?php echo Form::select('tax_id', $taxes, null, [
                    'class' => 'form-control select2',
                    'style' => 'width:100%',
                    'id' => 'product_list_filter_tax_id',
                    'placeholder' => __('lang_v1.all'),
                    ]); ?>

                </div>
            </div>
            <div class="col-md-3 hide">
                <div class="form-group">
                    <?php echo Form::label('brand_id', __('product.brand') . ':'); ?>

                    <?php echo Form::select('brand_id', $brands, null, ['class' => 'form-control select2', 'style' =>
                    'width:100%', 'id' => 'product_list_filter_brand_id', 'placeholder' => __('lang_v1.all')]); ?>

                </div>
            </div>
            <div class="col-md-3" id="location_filter">
                <div class="form-group">
                    <?php echo Form::label('location_id', __('purchase.business_location') . ':'); ?>

                    <?php echo Form::select('location_id', $business_locations, null, ['class' => 'form-control select2',
                    'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('active_state', __('sale.status') . ':'); ?>

                    <?php echo Form::select('active_state', ['active' => __('business.is_active'), 'inactive' =>
                    __('lang_v1.inactive')], null, ['class' => 'form-control select2', 'style' => 'width:100%', 'id' =>
                    'active_state', 'placeholder' => __('lang_v1.all')]); ?>

                </div>
            </div>

            <!-- include module filter -->
            <?php if(!empty($pos_module_data)): ?>
            <?php $__currentLoopData = $pos_module_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($value['view_path'])): ?>
            <?php if ($__env->exists($value['view_path'], ['view_data' => $value['view_data']])) echo $__env->make($value['view_path'], ['view_data' => $value['view_data']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <div class="col-md-3">
                <div class="form-group">
                    <br>
                    <label>
                        <?php echo Form::checkbox('not_for_selling', 1, false, ['class' => 'input-icheck', 'id' =>
                        'not_for_selling']); ?> <strong><?php echo app('translator')->get('lang_v1.not_for_selling'); ?></strong>
                    </label>
                </div>
            </div>
            <?php if($is_woocommerce): ?>
            <div class="col-md-3">
                <div class="form-group">
                    <br>
                    <label>
                        <?php echo Form::checkbox('woocommerce_enabled', 1, false,
                        [ 'class' => 'input-icheck', 'id' => 'woocommerce_enabled']); ?>

                        <?php echo e(__('lang_v1.woocommerce_enabled'), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.view')): ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="#product_list_tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-cubes"
                                aria-hidden="true"></i> <?php echo app('translator')->get('lang_v1.all_products'); ?></a>
                    </li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane active" id="product_list_tab">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.create')): ?>
                        <a class="btn btn-primary pull-right" href="<?php echo e(action('ProductController@create'), false); ?>">
                            <i class="fa fa-plus"></i> <?php echo app('translator')->get('messages.add'); ?></a>
                        <br><br>
                        <?php endif; ?>
                        <?php echo $__env->make('product.partials.product_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <input type="hidden" id="is_rack_enabled" value="<?php echo e($rack_enabled, false); ?>">

    <div class="modal fade product_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
    </div>

    <div class="modal fade" id="view_product_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
    </div>

    <div class="modal fade" id="opening_stock_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
    </div>

    <?php echo $__env->make('product.partials.edit_product_location_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/product.js?v=' . $asset_v), false); ?>"></script>
<script src="<?php echo e(asset('js/opening_stock.js?v=' . $asset_v), false); ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
    product_table = $('#product_table').DataTable({
        processing: true,
        serverSide: true,
        aaSorting: [
            [3, 'asc']
        ],
        scrollY: "500px",
        scrollX: true,
        scrollCollapse: true,
        "ajax": {
            "url": "/products",
            "data": function(d) {
                d.type = $('#product_list_filter_type').val();
                d.category_id = $('#product_list_filter_category_id').val();
                d.brand_id = $('#product_list_filter_brand_id').val();
                d.unit_id = $('#product_list_filter_unit_id').val();
                d.tax_id = $('#product_list_filter_tax_id').val();
                d.active_state = $('#active_state').val();
                d.not_for_selling = $('#not_for_selling').is(':checked');
                d.location_id = $('#location_id').val();
                if ($('#repair_model_id').length == 1) {
                    d.repair_model_id = $('#repair_model_id').val();
                }

                if ($('#woocommerce_enabled').length == 1 && $('#woocommerce_enabled').is(
                        ':checked')) {
                    d.woocommerce_enabled = 1;
                }

                d = __datatable_ajax_callback(d);
            }
        },
        columnDefs: [{
            "targets": [0, 1, 2],
            "orderable": false,
            "searchable": false
        }],
        columns: [{
                data: 'mass_delete'
            },
            {
                data: 'image',
                name: 'products.image'
            },
            {
                data: 'action',
                name: 'action'
            },
            {
                data: 'product',
                name: 'products.name'
            },
            {
                data: 'product_locations',
                name: 'product_locations'
            },
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_purchase_price')): ?> {
                data: 'purchase_price',
                name: 'max_purchase_price',
                searchable: false
            },
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_default_selling_price')): ?> {
                data: 'selling_price',
                name: 'max_price',
                searchable: false
            },
            <?php endif; ?> {
                data: 'type',
                name: 'products.type'
            },
            {
                data: 'product_tax',
                name: 'product_tax'
            },
            {
                data: 'category',
                name: 'c1.name'
            },
            {
                data: 'tax',
                name: 'tax_rates.name',
                searchable: false
            },
            {
                data: 'sku',
                name: 'products.sku'
            },
            {
                data: 'product_custom_field1',
                name: 'products.product_custom_field1'
            },
            {
                data: 'product_custom_field2',
                name: 'products.product_custom_field2'
            },
            {
                data: 'product_custom_field3',
                name: 'products.product_custom_field3'
            },
            {
                data: 'product_custom_field4',
                name: 'products.product_custom_field4'
            }

        ],
        createdRow: function(row, data, dataIndex) {
            if ($('input#is_rack_enabled').val() == 1) {
                var target_col = 0;
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.delete')): ?>
                target_col = 1;
                <?php endif; ?>
                $(row).find('td:eq(' + target_col + ') div').prepend(
                    '<i style="margin:auto;" class="fa fa-plus-circle text-success cursor-pointer no-print rack-details" title="' +
                    LANG.details + '"></i>&nbsp;&nbsp;');
            }
            $(row).find('td:eq(0)').attr('class', 'selectable_td');
        },
        fnDrawCallback: function(oSettings) {
            __currency_convert_recursively($('#product_table'));
        },
    });
    // Array to track the ids of the details displayed rows
    var detailRows = [];

    $('#product_table tbody').on('click', 'tr i.rack-details', function() {
        var i = $(this);
        var tr = $(this).closest('tr');
        var row = product_table.row(tr);
        var idx = $.inArray(tr.attr('id'), detailRows);

        if (row.child.isShown()) {
            i.addClass('fa-plus-circle text-success');
            i.removeClass('fa-minus-circle text-danger');

            row.child.hide();

            // Remove from the 'open' array
            detailRows.splice(idx, 1);
        } else {
            i.removeClass('fa-plus-circle text-success');
            i.addClass('fa-minus-circle text-danger');

            row.child(get_product_details(row.data())).show();

            // Add to the 'open' array
            if (idx === -1) {
                detailRows.push(tr.attr('id'));
            }
        }
    });

    $('table#product_table tbody').on('click', 'a.delete-product', function(e) {
        e.preventDefault();
        swal({
            title: LANG.sure,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                var href = $(this).attr('href');
                $.ajax({
                    method: "DELETE",
                    url: href,
                    dataType: "json",
                    success: function(result) {
                        if (result.success == true) {
                            toastr.success(result.msg);
                            product_table.ajax.reload();
                        } else {
                            toastr.error(result.msg);
                        }
                    }
                });
            }
        });
    });

    $(document).on('click', '#delete-selected', function(e) {
        e.preventDefault();
        var selected_rows = getSelectedRows();

        if (selected_rows.length > 0) {
            $('input#selected_rows').val(selected_rows);
            swal({
                title: LANG.sure,
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    $('form#mass_delete_form').submit();
                }
            });
        } else {
            $('input#selected_rows').val('');
            swal('<?php echo app('translator')->get("lang_v1.no_row_selected "); ?>');
        }
    });

    $(document).on('click', '#sync-with-deliverect', function(e) {
        e.preventDefault();
        var selected_rows = getSelectedRows();

        // get the current location_id
        locationId = $("#location_id").val()
        if (!locationId) {
            toastr.error("Select a business id");
            return;
        }

        const businessId = $("#business_id").val()
        url = `/api/deliverect/${businessId}/${locationId}/registration-status`;
        $.ajax({
            method: "GET",
            url: url,
            dataType: 'json',
            data: {
                "selected_rows": selected_rows
            },
            success: function(result) {
                console.log(result);
                if (result['data']['status']) {
                    console.log(
                        "Business is registered we can proceed with product synchronization!"
                    )
                    if (selected_rows.length > 0) {
                        $('input#selected_rows').val(selected_rows);

                        swal({
                            title: LANG.sure,
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                        }).then((isSure) => {
                            if (isSure) {
                                toastr.success("Syncing with Deliverect...");
                                var form = $('form#sync_with_deliverect_form')

                                var data = form.serialize();
                                $.ajax({
                                    method: form.attr('method'),
                                    url: form.attr('action'),
                                    dataType: 'json',
                                    data: {
                                        "selected_rows": selected_rows,
                                        "location_id": locationId,
                                    },
                                    success: function(result) {
                                        if (result.success ==
                                            true) {
                                            toastr.success(
                                                "Successfully synced with Deliverect"
                                            );
                                            form
                                                .find(
                                                    '#selected_products'
                                                )
                                                .val('');
                                            $('.select-all-product-row')
                                                .prop('checked',
                                                    false).change();
                                        } else {
                                            toastr.success(
                                                "Failed to sync with Deliverect"
                                            );
                                        }
                                    },
                                });
                            }
                        });
                    } else {
                        $('input#selected_rows').val('');
                        swal('<?php echo app('translator')->get("lang_v1.no_row_selected"); ?>');
                    }
                } else {
                    toastr.error(
                        "Register the business in Deliverect before syncing!!");

                }
            },
        });
    });

    $(document).on('click', '#deactivate-selected', function(e) {
        e.preventDefault();
        var selected_rows = getSelectedRows();

        if (selected_rows.length > 0) {
            $('input#selected_products').val(selected_rows);
            swal({
                title: LANG.sure,
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    var form = $('form#mass_deactivate_form')

                    var data = form.serialize();
                    $.ajax({
                        method: form.attr('method'),
                        url: form.attr('action'),
                        dataType: 'json',
                        data: data,
                        success: function(result) {
                            if (result.success == true) {
                                toastr.success(result.msg);
                                product_table.ajax.reload();
                                form
                                    .find('#selected_products')
                                    .val('');
                                $('.select-all-product-row').prop('checked',
                                    false).change();
                            } else {
                                toastr.error(result.msg);
                            }
                        },
                    });
                }
            });
        } else {
            $('input#selected_products').val('');
            swal('<?php echo app('translator')->get("lang_v1.no_row_selected"); ?>');
        }
    })

    $(document).on('click', '#edit-selected', function(e) {
        e.preventDefault();
        var selected_rows = getSelectedRows();

        if (selected_rows.length > 0) {
            $('input#selected_products_for_edit').val(selected_rows);
            $('form#bulk_edit_form').submit();
        } else {
            $('input#selected_products').val('');
            swal('<?php echo app('translator')->get("lang_v1.no_row_selected"); ?>');
        }
    })

    $('table#product_table tbody').on('click', 'a.activate-product', function(e) {
        e.preventDefault();
        var href = $(this).attr('href');
        $.ajax({
            method: "get",
            url: href,
            dataType: "json",
            success: function(result) {
                if (result.success == true) {
                    toastr.success(result.msg);
                    product_table.ajax.reload();
                } else {
                    toastr.error(result.msg);
                }
            }
        });
    });

    $(document).on('change',
        '#product_list_filter_type, #product_list_filter_category_id, #product_list_filter_brand_id, #product_list_filter_unit_id, #product_list_filter_tax_id, #location_id, #active_state, #repair_model_id',
        function() {
            if ($("#product_list_tab").hasClass('active')) {
                product_table.ajax.reload();
            }


        });

    $(document).on('ifChanged', '#not_for_selling, #woocommerce_enabled', function() {
        if ($("#product_list_tab").hasClass('active')) {
            product_table.ajax.reload();
        }


    });

    $('#product_location').select2({
        dropdownParent: $('#product_location').closest('.modal')
    });
});

$(document).on('shown.bs.modal', 'div.view_product_modal, div.view_modal',
    function() {
        var div = $(this).find('#view_product_stock_details');
        if (div.length) {
            $.ajax({
                url: "<?php echo e(action('ReportController@getStockReport'), false); ?>" + '?for=view_product&product_id=' + div
                    .data('product_id'),
                dataType: 'html',
                success: function(result) {
                    div.html(result);
                    __currency_convert_recursively(div);
                },
            });
        }
        __currency_convert_recursively($(this));
    });
var data_table_initailized = false;
$('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
    product_table.ajax.reload();
});

function getSelectedRows() {
    var selected_rows = [];
    var i = 0;
    $('.row-select:checked').each(function() {
        selected_rows[i++] = $(this).val();
    });

    return selected_rows;
}

$(document).on('change', 'input.select-row-product', function() {
    let selectRowProduct = $('#product_table  input:checkbox:checked').length;
    let tbodyTotalCheckbox = $('#product_table tbody input:checkbox').length;
    if ($('.select-all-product-row:checkbox:checked')) {
        if (selectRowProduct < tbodyTotalCheckbox) {
            $('.select-all-product-row').prop('checked', false).change();
        }
    }
    if (this.checked) {
        $(this)
            .closest('tr')
            .addClass('selected');
    } else {
        $(this)
            .closest('tr')
            .removeClass('selected');
    }
});

// select all row
$(document).on('click', '.select-all-product-row', function(e) {
    if (this.checked) {
        $(this)
            .closest('table').parent().parent().next().find('table').find('tbody')
            .find('input.row-select')
            .each(function() {
                if (!this.checked) {
                    $(this)
                        .prop('checked', true);
                    $(this)
                        .closest('tr')
                        .addClass('selected')
                }
            });
    } else {
        $(this)
            .closest('table').parent().parent().next().find('table').find('tbody')
            .find('input.row-select')
            .each(function() {
                if (this.checked) {
                    $(this)
                        .prop('checked', false);
                    $(this)
                        .closest('tr')
                        .removeClass('selected');
                }
            });
    }
});

$(document).on('click', '.update_product_location', function(e) {
    e.preventDefault();
    var selected_rows = getSelectedRows();

    if (selected_rows.length > 0) {
        $('input#selected_products').val(selected_rows);
        var type = $(this).data('type');
        var modal = $('#edit_product_location_modal');
        if (type == 'add') {
            modal.find('.remove_from_location_title').addClass('hide');
            modal.find('.add_to_location_title').removeClass('hide');
        } else if (type == 'remove') {
            modal.find('.add_to_location_title').addClass('hide');
            modal.find('.remove_from_location_title').removeClass('hide');
        }

        modal.modal('show');
        modal.find('#product_location').select2({
            dropdownParent: modal
        });
        modal.find('#product_location').val('').change();
        modal.find('#update_type').val(type);
        modal.find('#products_to_update_location').val(selected_rows);
    } else {
        $('input#selected_products').val('');
        swal('<?php echo app('translator')->get("lang_v1.no_row_selected"); ?>');
    }
});

$(document).on('submit', 'form#edit_product_location_form', function(e) {
    e.preventDefault();
    $(this)
        .find('button[type="submit"]')
        .attr('disabled', true);
    var data = $(this).serialize();

    $.ajax({
        method: $(this).attr('method'),
        url: $(this).attr('action'),
        dataType: 'json',
        data: data,
        success: function(result) {
            if (result.success == true) {
                $('div#edit_product_location_modal').modal('hide');
                toastr.success(result.msg);
                product_table.ajax.reload();
                $('form#edit_product_location_form')
                    .find('button[type="submit"]')
                    .attr('disabled', false);
                $('.select-all-product-row').prop('checked', false).change();
            } else {
                toastr.error(result.msg);
            }
        },
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/product/index.blade.php ENDPATH**/ ?>