<?php if(!session('business.enable_price_tax')): ?>
<?php
$default = 0;
$class = 'hide';
?>
<?php else: ?>
<?php
$default = null;
$class = '';
?>
<?php endif; ?>

<div class="table-responsive">
    <table class="table table-bordered add-product-price-table table-condensed <?php echo e($class, false); ?>">
        <tr>
            <th colspan='2'><?php echo app('translator')->get('product.default_purchase_price'); ?></th>
            <th class=""><?php echo app('translator')->get('product.profit_percent'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.profit_percent') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
            <th colspan='2'><?php echo app('translator')->get('product.default_selling_price'); ?></th>
            <th></th>
            <?php if(empty($quick_add)): ?>
            
            <?php endif; ?>
        </tr>
        <tr>
            <td>
                <br />
                <div class="input-group">
                    <span class="input-group-addon"><small><?php echo app('translator')->get('product.inc_of_tax'); ?></small></span>
                    <?php echo Form::text('single_dpp_inc_tax', '', ['class' => 'form-control input-sm dpp input_number',
                    'id'=>'single_dpp_inc_tax', 'placeholder' => __('product.inc_of_tax')]); ?>

                </div>
            </td>
            <td>
                <br />
                <div class="input-group">
                    <span class="input-group-addon"><small> <?php echo app('translator')->get('product.exc_of_tax'); ?></small></span>
                    <?php echo Form::text('default_purchase_price', '', ['placeholder' => __('product.exc_of_tax'), 'id'
                    =>'default_purchase_price', 'class' => 'form-control input-sm input_number pp_exc_tax']); ?>

                </div>
            </td>

            <td class="">
                <br />
                <?php echo Form::text('profit_percent', number_format($profit_percent, config('constants.currency_precision', 2), session('currency')['decimal_separator'], session('currency')['thousand_separator']), ['class' => 'form-control input-sm
                input_number', 'id' => 'profit_percent', 'required']); ?>

            </td>

            <td>
                <?php echo Form::label('dsp_label', trans('product.inc_of_tax') . ':*'); ?>

                <!--  <?php echo Form::text('single_dsp', $default, ['class' => 'form-control input-sm dsp input_number', 'placeholder' => __('product.exc_of_tax'), 'id' => 'single_dsp', 'required']); ?> -->
                <?php echo Form::text('single_dsp_inc_tax', $default, ['class' => 'form-control input-sm input_number',
                'placeholder' => __('product.inc_of_tax'), 'id' => 'single_dsp_inc_tax', 'required']); ?>

            </td>
            <td>
                <div class="col-sm-6">
                    <?php echo Form::label('single_dpp', trans('product.exc_of_tax') ); ?>

                    <?php echo Form::text('single_dpp', $default, ['class' => 'form-control input-sm dpp input_number',
                    'placeholder' => __('product.exc_of_tax')]); ?>

                </div>

                <!-- 5- please make this field visible but disabled, the purpose of it is to see the price after VAT, but it confuse users as it is shown as an entry field -->
                <div class="col-sm-6">
                    <?php echo Form::label('applicable_tax', trans('product.applicable_tax')); ?>

                    <?php echo Form::text('applicable_tax', $default, ['class' => 'form-control input-sm input_number',
                    'readonly'=> 'true', 'style'=>'border: none', 'placeholder' => __('product.applicable_tax')]); ?>

                </div>
            </td>
            <?php if(empty($quick_add)): ?>
            
            
            
            
            
            
            
            <?php endif; ?>
        </tr>
    </table>
</div>
<?php /**PATH /home/paneltech/panel/resources/views/product/partials/single_product_form_part.blade.php ENDPATH**/ ?>