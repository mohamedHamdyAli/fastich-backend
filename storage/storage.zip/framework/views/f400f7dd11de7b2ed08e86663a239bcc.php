<div class="modal-dialog" role="document">
  <div class="modal-content">

    <?php echo Form::open(['url' => action('CallNumberSchemeController@update', [$call_Number->id]), 'method' => 'put', 'id' => 'call_number_scheme_add_form' ]); ?>


    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title"><?php echo app('translator')->get( 'invoice.edit_call_number' ); ?></h4>
    </div>

    <div class="modal-body">
      <div class="row">
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('name', __( 'invoice.name' ) . ':*'); ?>

              <?php echo Form::text('name', $call_Number->name, ['class' => 'form-control', 'required', 'placeholder' => __( 'invoice.name' ) ]); ?>

          </div>
        </div>
        <div id="invoice_format_settings">
        <div class="clearfix">
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('total_digits', __( 'invoice.total_digits' ) . ':'); ?>

            <div class="input-group col-md-12 col-sm-12">
              <span class="input-group-addon">
                  <i class="fa fa-info"></i>
              </span>
              <?php echo Form::select('total_digits', ['3' => '3','4' => '4', '5' => '5', '6' => '6', '7' => '7', 
              '8' => '8', '9'=>'9', '10' => '10'], $call_Number->total_digits, ['class' => 'form-control', 'required']); ?>

            </div>
          </div>
        </div>
         <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('last_call_number_end', __( 'invoice.last_call_number_end' ) . ':'); ?>

            <div class="input-group col-md-12 col-sm-12">
              <span class="input-group-addon">
                  <i class="fa fa-info"></i>
              </span>
                <?php echo Form::number('last_call_number_end', $call_Number->last_call_number_end, ['class' => 'form-control', 'required', 'min' => 0 ]); ?>

            </div>
          </div>
        </div>
        </div>
      </div>
    </div>

    <div class="modal-footer">
      <button type="submit" class="btn btn-primary"><?php echo app('translator')->get( 'messages.save' ); ?></button>
      <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->get( 'messages.close' ); ?></button>
    </div>

    <?php echo Form::close(); ?>


  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog --><?php /**PATH /home/paneltech/panel/resources/views/call_number_scheme/edit.blade.php ENDPATH**/ ?>