<?php
    $heading = !empty($module_category_data['heading']) ? $module_category_data['heading'] : __('category.categories');
    $navbar = !empty($module_category_data['navbar']) ? $module_category_data['navbar'] : null;
?>
<?php $__env->startSection('title', $heading); ?>

<?php $__env->startSection('content'); ?>
<?php if(!empty($navbar)): ?>
    <?php echo $__env->make($navbar, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo e($heading, false); ?>

        <small>
            <?php echo e($module_category_data['sub_heading'] ?? __( 'category.manage_your_categories' ), false); ?>

        </small>
        <?php if(isset($module_category_data['heading_tooltip'])): ?>
            <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . $module_category_data['heading_tooltip'] . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        <?php endif; ?>
    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
    </ol> -->
</section>

<!-- Main content -->
<section class="content">
    <?php
        $cat_code_enabled = isset($module_category_data['enable_taxonomy_code']) && !$module_category_data['enable_taxonomy_code'] ? false : true;
    ?>
    <input type="hidden" id="category_type" value="<?php echo e(request()->get('type'), false); ?>">
    <?php $__env->startComponent('components.widget', ['class' => 'box-solid']); ?>
            <?php $__env->slot('tool'); ?>
                <div class="box-tools">
                    <button type="button" class="btn btn-block btn-primary btn-modal"
                    data-href="<?php echo e(action('TaxonomyController@create'), false); ?>?type=<?php echo e(request()->get('type'), false); ?>"
                    data-container=".category_modal">
                    <i class="fa fa-plus"></i> <?php echo app('translator')->get( 'messages.add' ); ?></button>
                </div>
            <?php $__env->endSlot(); ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="category_table">
                    <thead>
                        <tr>
                        <th><?php echo app('translator')->get( 'lang_v1.image' ); ?></th>
                            <th><?php if(!empty($module_category_data['taxonomy_label'])): ?> <?php echo e($module_category_data['taxonomy_label'], false); ?> <?php else: ?> <?php echo app('translator')->get( 'category.category' ); ?> <?php endif; ?></th>
                            <?php if($cat_code_enabled): ?>
                                <th><?php echo e($module_category_data['taxonomy_code_label'] ?? __( 'category.code' ), false); ?></th>
                            <?php endif; ?>
                            <th> <?php echo app('translator')->get('lang_v1.assign_unassign_locations'); ?> </th>
                            <th> <?php echo app('translator')->get('lang_v1.assign_unassign_modifiers'); ?> </th>
                            <th><?php echo app('translator')->get( 'restaurant.modifier_sets' ); ?></th>
                            <th><?php echo app('translator')->get( 'lang_v1.product' ); ?></th>
                            <th><?php echo app('translator')->get( 'lang_v1.created_at' ); ?></th>
                            <th><?php echo app('translator')->get( 'lang_v1.updated_at' ); ?></th>
                            <th><?php echo app('translator')->get( 'messages.action' ); ?></th>
                        </tr>
                    </thead>
                </table>

            </div>
    <?php echo $__env->renderComponent(); ?>

    <div class="modal fade category_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">  </div>

    <div class="modal fade addCategoryModifiersModal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>

    <div class="modal fade addLocationsModal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>



</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        let defaultImage = "<?php echo e(asset('/img/default.png'), false); ?>";
        function myFunction(categoryModifiersID){
            $('#categoryID').val(categoryModifiersID);
            // $.ajax({
            //     url: '/taxonomies/loadModifiersTable/'+categoryModifiersID,
            //     dataType : 'json',
            //     success: function(result){

            //         if(result){
            //             var html ='';
            //             html += '<input type="text" name="categoryID" id="categoryID" value="'+categoryModifiersID+'"/> ';

            //             $('#addCategoryModifiersModal').modal('show');

            //             //$('#addCategoryModifiersModal .modal-body').html(html);

            //             var elmnt = $('#modifiers_ids') ;
            //             alert(elmnt);
            //             document.getElementById("modifiers_ids").options.selectedIndex = 124;
            //             // for(var i=0; i < elmnt.options.length; i++)
            //             //     {
            //             //         if(elmnt.options[i].value === value) {
            //             //         elmnt.selectedIndex = i;
            //             //         break;
            //             //         }
            //             //     }

            //         } else {

            //         }
            //     }

            // });
        }

        $(function () {
            // $('#save_category_modifiers').on('click', function () {
            //     var ids = $('#modifiers_ids').val();
            //     var categoryID = $('#categoryID').val();

            //     $.ajax({
            //         url: '/taxonomies/add_modifiers/'+categoryID,
            //         data: {
            //         modifiers_ids: ids,
            //         },
            //         dataType : 'json',
            //         success: function(result){
            //             if(result.success == true){
            //                 $('#addCategoryModifiersModal').modal('hide');
            //                 toastr.success(result.msg);
            //                 //modifier_table.ajax.reload();
            //                 //location.reload();
            //             } else {
            //                 toastr.error(result.msg);
            //             }
            //         }
            //         });

            // });

      //Brands table
    //   var modifier_table = $('#modifier_table').DataTable({
    //           searching: false,
    //           paging: false,
    //           info: false,
    //           processing: true,
    //           serverSide: true,
    //           ajax: '/products/loadModifiersTable/'+product_id,
    //           columnDefs: [ {
    //               "targets": [1],
    //               "orderable": false,
    //               "searchable": false
    //           } ],
    //           columns: [
    //               { data: 'name', name: 'name'  },
    //               { data: 'variations', name: 'variations'},

    //           ],
    //   });
  });
    </script>
<?php if ($__env->exists('taxonomy.taxonomies_js')) echo $__env->make('taxonomy.taxonomies_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/taxonomy/index.blade.php ENDPATH**/ ?>