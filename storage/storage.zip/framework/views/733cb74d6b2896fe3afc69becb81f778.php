
<?php $__env->startSection('title', __('home.home')); ?>

<?php $__env->startSection('content'); ?>




<!-- Content Header (Page header) -->
<section class="content-header content-header-custom">
    <h1><?php echo e(__('home.welcome_message', ['name' => Session::get('user.first_name')]), false); ?>

    </h1>
    <input id="termsConditionNotDone" type="hidden" value=<?php echo e($termsConditionNotDoneStatus, false); ?> />
</section>
<!-- Main content -->
<section class="content content-custom no-print">
    <br>
    <?php if(auth()->user()->can('dashboard.data')): ?>
    <div class="row">

        <div class="col-md-4 col-xs-12">
            <?php if(count($all_locations) > 1): ?>
            <?php echo Form::select('dashboard_location', $all_locations, null, [
            'class' => 'form-control select2',
            'placeholder' => __('lang_v1.select_location'),
            'id' => 'dashboard_location',
            ]); ?>

            <?php endif; ?>
        </div>
        <div class="col-md-8 col-xs-12">
            <div class="btn-group pull-right" data-toggle="buttons">
                <label class="btn btn-info active">
                    <input checked data-end="<?php echo e($date_filters['yesterday'], false); ?>"
                        data-start="<?php echo e($date_filters['yesterday'], false); ?>" name="date-filter"
                        type="radio"><?php echo e(__('home.yesterday'), false); ?>

                </label>
                <label class="btn btn-info active">
                    <input checked data-end="<?php echo e(date('Y-m-d'), false); ?>" data-start="<?php echo e(date('Y-m-d'), false); ?>" name="date-filter"
                        type="radio"> <?php echo e(__('home.today'), false); ?>

                </label>
                <label class="btn btn-info">
                    <input data-end="<?php echo e($date_filters['this_week']['end'], false); ?>"
                        data-start="<?php echo e($date_filters['this_week']['start'], false); ?>" name="date-filter" type="radio">
                    <?php echo e(__('home.this_week'), false); ?>

                </label>
                <label class="btn btn-info">
                    <input data-end="<?php echo e($date_filters['this_month']['end'], false); ?>"
                        data-start="<?php echo e($date_filters['this_month']['start'], false); ?>" name="date-filter" type="radio">
                    <?php echo e(__('home.this_month'), false); ?>

                </label>
                <label class="btn btn-info">
                    <input data-end="<?php echo e($date_filters['this_fy']['end'], false); ?>"
                        data-start="<?php echo e($date_filters['this_fy']['start'], false); ?>" name="date-filter" type="radio">
                    <?php echo e(__('home.this_fy'), false); ?>

                </label>
            </div>
        </div>
    </div>
    <br>
    <div class="row row-custom">
        <!-- Total Sales -->
        <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
            <div class="info-box info-box-new-style">
                <span class="info-box-icon bg-aqua"><i class="ion ion-ios-cart-outline"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(__('home.total_sell'), false); ?></span>
                    <span class="info-box-number total_sell"><i
                            class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
                </div>
            </div>
        </div>
        <!-- /.col -->

        <!-- Total Paid Payment -->
        <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
            <div class="info-box info-box-new-style">
                <span class="info-box-icon bg-aqua"><i class="ion ion-ios-cart-outline"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(__('home.total_net_payment'), false); ?></span>
                    <span class="info-box-number total_paid_payment"><i
                            class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
                </div>
            </div>
        </div>
        <!-- /.col -->

        <!-- Total Reurn Payment -->
        <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
            <div class="info-box info-box-new-style">
                <span class="info-box-icon bg-aqua"><i class="ion ion-ios-cart-outline"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(__('home.total_returned'), false); ?></span>
                    <span class="info-box-number total_return_payment"><i
                            class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
                </div>
            </div>
        </div>
        <!-- /.col -->

        <div class="col-md-3 col-sm-6 col-xs-12 col-custom hide">
            <div class="info-box info-box-new-style">
                <span class="info-box-icon bg-aqua"><i class="ion ion-cash"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(__('home.total_purchase'), false); ?></span>
                    <span class="info-box-number total_purchase"><i
                            class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12 col-custom hide">
            <div class="info-box info-box-new-style">
                <span class="info-box-icon bg-yellow">
                    <i class="fa fa-dollar"></i>
                    <i class="fa fa-exclamation"></i>
                </span>

                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(__('home.purchase_due'), false); ?></span>
                    <span class="info-box-number purchase_due"><i
                            class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>



        <!-- fix for small devices only -->
        <!-- <div class="clearfix visible-sm-block"></div> -->
        <div class="col-md-3 col-sm-6 col-xs-12 col-custom hide">
            <div class="info-box info-box-new-style">
                <span class="info-box-icon bg-yellow">
                    <i class="ion ion-ios-paper-outline"></i>
                    <i class="fa fa-exclamation"></i>
                </span>

                <div class="info-box-content">
                    <span class="info-box-text"><?php echo e(__('home.invoice_due'), false); ?></span>
                    <span class="info-box-number invoice_due"><i
                            class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
    </div>
    <div class="row row-custom hide">
        <!-- expense -->
        <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
            <div class="info-box info-box-new-style">
                <span class="info-box-icon bg-red">
                    <i class="fas fa-minus-circle"></i>
                </span>

                <div class="info-box-content">
                    <span class="info-box-text">
                        <?php echo e(__('lang_v1.expense'), false); ?>

                    </span>
                    <span class="info-box-number total_expense"><i
                            class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
    </div>
    <div id="after_sale_purchase_totals">

    </div>
    
    <?php if(!empty($all_locations)): ?>
    <!-- sales chart start -->
    <div class="row">
        <div class="col-sm-12">

            <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' => __('home.sells_last_07_days')]); ?>
            <div id="sell_chart_one"></div>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php endif; ?>
    <div id="after_sales_last_30_days">

    </div>
    
    <?php if(!empty($all_locations)): ?>
    <div class="row">
        <div class="col-sm-12">
            <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' => __('home.sells_current_fy')]); ?>
            <div id="chart_for_this_fy">

            </div>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php endif; ?>
    <!-- sales chart end -->

    <div id="after_sales_current_fy">

    </div>
    
    <!-- products less than alert quntity -->

    <div class="row">

        <div class="col-sm-6">
            <?php $__env->startComponent('components.widget', ['class' => 'box-warning']); ?>
            <?php $__env->slot('icon'); ?>
            <i aria-hidden="true" class="fa fa-exclamation-triangle text-yellow"></i>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('title'); ?>
            <?php echo e(__('lang_v1.sales_payment_dues'), false); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('lang_v1.tooltip_sales_payment_dues') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
            <?php $__env->endSlot(); ?>
            <table class="table table-bordered table-striped" id="sales_payment_dues_table">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('contact.customer'); ?></th>
                        <th><?php echo app('translator')->get('sale.invoice_no'); ?></th>
                        <th><?php echo app('translator')->get('home.due_amount'); ?></th>
                    </tr>
                </thead>
            </table>
            <?php echo $__env->renderComponent(); ?>
        </div>

        <div class="col-sm-6">
            <?php $__env->startComponent('components.widget', ['class' => 'box-warning']); ?>
            <?php $__env->slot('icon'); ?>
            <i aria-hidden="true" class="fa fa-exclamation-triangle text-yellow"></i>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('title'); ?>
            <?php echo e(__('lang_v1.purchase_payment_dues'), false); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.payment_dues') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
            <?php $__env->endSlot(); ?>
            <table class="table table-bordered table-striped" id="purchase_payment_dues_table">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('purchase.supplier'); ?></th>
                        <th><?php echo app('translator')->get('purchase.ref_no'); ?></th>
                        <th><?php echo app('translator')->get('home.due_amount'); ?></th>
                    </tr>
                </thead>
            </table>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>


    <div class="row">
        <div class="<?php if(session('business.enable_product_expiry') != 1 &&
                        auth()->user()->can('stock_report.view')): ?> col-sm-12 <?php else: ?> col-sm-6 <?php endif; ?>">
            <?php $__env->startComponent('components.widget', ['class' => 'box-warning']); ?>
            <?php $__env->slot('icon'); ?>
            <i aria-hidden="true" class="fa fa-exclamation-triangle text-yellow"></i>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('title'); ?>
            <?php echo e(__('home.product_stock_alert'), false); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.product_stock_alert') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
            <?php $__env->endSlot(); ?>
            <table class="table table-bordered table-striped" id="stock_alert_table">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('sale.product'); ?></th>
                        <th><?php echo app('translator')->get('business.location'); ?></th>
                        <th><?php echo app('translator')->get('report.current_stock'); ?></th>
                    </tr>
                </thead>
            </table>
            <?php echo $__env->renderComponent(); ?>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock_report.view')): ?>
        <?php if(session('business.enable_product_expiry') == 1): ?>
        <div class="col-sm-6">
            <?php $__env->startComponent('components.widget', ['class' => 'box-warning']); ?>
            <?php $__env->slot('icon'); ?>
            <i aria-hidden="true" class="fa fa-exclamation-triangle text-yellow"></i>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('title'); ?>
            <?php echo e(__('home.stock_expiry_alert'), false); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.stock_expiry_alert', [ 'days'
            =>session('business.stock_expiry_alert_days', 30) ]) . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
            <?php $__env->endSlot(); ?>
            <input id="stock_expiry_alert_days" type="hidden"
                value="<?php echo e(\Carbon::now()->addDays(session('business.stock_expiry_alert_days', 30))->format('Y-m-d'), false); ?>">
            <table class="table table-bordered table-striped" id="stock_expiry_alert_table">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('business.product'); ?></th>
                        <th><?php echo app('translator')->get('business.location'); ?></th>
                        <th><?php echo app('translator')->get('report.stock_left'); ?></th>
                        <th><?php echo app('translator')->get('product.expires_in'); ?></th>
                    </tr>
                </thead>
            </table>
            <?php echo $__env->renderComponent(); ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <div id="after_dashboard_reports">

    </div>
    
    <?php endif; ?>
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>

<script src="<?php echo e(asset('js/home.js?v=' . $asset_v), false); ?>"></script>
<script>
function getHomeWidgets() {
    $.ajax({
        url: "<?php echo e(route('home_widgets'), false); ?>",
        method: 'GET',
        success: function(response) {
            // Handle the response data as needed
            console.log(response);
            const widgts = response['widgets'];
            if (widgts['after_sale_purchase_totals']) {
                $("#after_sale_purchase_totals").html(widgts['after_sale_purchase_totals']);
            }
            if (widgts['after_sales_last_30_days']) {
                $("#after_sales_last_30_days").html(widgts['after_sales_last_30_days']);
            }
            if (widgts['after_sales_current_fy']) {
                $("#after_sales_current_fy").html(widgts['after_sales_current_fy']);
            }
            if (widgts['after_dashboard_reports']) {
                $("#after_dashboard_reports").html(widgts['after_dashboard_reports']);
            }

        },
        error: function(error) {
            // Handle errors if any
            console.error(error);
        }
    });
}
let can_dashboard_data;

const financialYear = <?php echo isset($financialYear) ? json_encode($financialYear) : 'undefined'; ?>;
const currency = <?php echo isset($currency) ? json_encode($currency) : 'undefined'; ?>;
const allLocations = <?php echo isset($all_locations) ? json_encode($all_locations) : 'undefined'; ?>;

// console.log(allLocations, financialYear, currency);


// Fetch Chart for Current Financial Year
function getChartForThisFY(financialYear, allLocations, currency) {
    const loader = '<i class="fas fa-sync fa-spin fa-fw margin-bottom"></i>';
    $("#chart_for_this_fy").html(loader);
    $.ajax({
        url: "<?php echo e(route('chart_for_this_fy'), false); ?>",
        method: 'POST',
        data: {
            financialYear: financialYear,
            all_locations: allLocations,
            currency: currency,
            "_token": "<?php echo e(csrf_token(), false); ?>"
        },
        success: function(response) {
            console.log(response);
            const dataset = response["dataset"];
            const title = response['title'];
            const labels = response['labels'];

            $("#chart_for_this_fy").html('');
            Highcharts.chart('chart_for_this_fy', {
                title: {
                    text: null
                },
                xAxis: {
                    categories: labels,
                    title: {
                        text: ""
                    }
                },
                credits: {
                    enabled: false
                },
                legend: {
                    align: 'right',
                },
                yAxis: {
                    title: {
                        text: title
                    }
                },
                tooltip: {
                    useHTML: true,
                    formatter: function() {
                        console.log(this)
                        return '<span style="white-space: nowrap;">' + this.x + '<br/>' +
                            '<span style="color:' + this.color + '">' + this.series.name +
                            '</span>: ' + this.y + '</span>';
                    },
                    shared: false
                },
                series: dataset
            });
        },
        error: function(error) {
            // Handle errors if any
            console.error(error);
        }
    });
}

function getSellChartOne(currency, allLocations) {
    const loader = '<i class="fas fa-sync fa-spin fa-fw margin-bottom"></i>';
    $("#sell_chart_one").html(loader);
    $.ajax({
        url: "<?php echo e(route('sell_chart_one'), false); ?>",
        method: 'POST',
        data: {
            currency: currency,
            all_locations: allLocations,
            "_token": "<?php echo e(csrf_token(), false); ?>"
        },
        success: function(response) {
            console.log(response);
            const dataset = response["dataset"];
            const title = response['title'];
            const labels = response['labels'];

            $("#sell_chart_one").html('');
            Highcharts.chart('sell_chart_one', {
                title: {
                    text: null
                },
                xAxis: {
                    categories: labels,
                    title: {
                        text: ""
                    }
                },
                credits: {
                    enabled: false
                },
                legend: {
                    align: 'right',
                },
                yAxis: {
                    title: {
                        text: title
                    }
                },
                tooltip: {
                    useHTML: true,
                    formatter: function() {
                        console.log(this)
                        return '<span style="white-space: nowrap;">' + this.x + '<br/>' +
                            '<span style="color:' + this.color + '">' + this.series.name +
                            '</span>: ' + this.y + '</span>';
                    },
                    shared: false
                },
                series: dataset
            });
        },
        error: function(error) {
            // Handle errors if any
            console.error(error);
        }
    });
}
if (
    typeof financialYear !== 'undefined' &&
    typeof currency !== 'undefined' &&
    typeof allLocations !== 'undefined'
) {
    const defaultStart = $('input[name="date-filter"]:checked').data('start');
    const defaultEnd = $('input[name="date-filter"]:checked').data('end');
    if (typeof update_statistics === 'function') {
        update_statistics(defaultStart, defaultEnd);
    }

    getHomeWidgets();
    getSellChartOne(currency, allLocations);
    getChartForThisFY(financialYear, allLocations, currency);
}
</script>
<?php if(!empty($all_locations)): ?>


<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/home/index.blade.php ENDPATH**/ ?>