<?php $__env->startSection('title', __('messages.business_location_settings')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->get( 'messages.business_location_settings' ); ?> - <?php echo e($location->name, false); ?></h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
    </ol> -->
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab_1" data-toggle="tab" aria-expanded="true"><?php echo app('translator')->get('receipt.receipt_settings'); ?></a></li>
                <?php if(in_array('kitchen_module',$enabled_modules)): ?>
                    <li class=""><a href="#tab_2" data-toggle="tab" aria-expanded="true"><?php echo e(__( 'messages.kitchen_station'), false); ?></a></li>
                <?php endif; ?>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="tab_1">
                    <div class="row">
                        <div class="col-md-12">
                            <h4><?php echo app('translator')->get( 'receipt.receipt_settings'); ?>
                                <small><?php echo app('translator')->get( 'receipt.receipt_settings_mgs'); ?></small>
                            </h4>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo Form::open(['url' => route('location.settings_update', [$location->id]), 'method' => 'post', 'id' => 'bl_receipt_setting_form']); ?>


                        <div class="col-sm-4">
                            <div class="form-group">
                                <?php echo Form::label('print_receipt_on_invoice', __('receipt.print_receipt_on_invoice') . ':'); ?>

                                <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.print_receipt_on_invoice') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-file-alt"></i>
                                    </span>
                                    <?php echo Form::select('print_receipt_on_invoice', $printReceiptOnInvoice, $location->print_receipt_on_invoice, ['class' => 'form-control select2', 'required']); ?>

                                </div>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="form-group">
                                <?php echo Form::label('receipt_printer_type', __('receipt.receipt_printer_type') . ':*'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.receipt_printer_type') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-print"></i>
                                    </span>
                                    <?php echo Form::select('receipt_printer_type', $receiptPrinterType, $location->receipt_printer_type, ['class' => 'form-control select2', 'required']); ?>

                                </div>
                                <?php if(config('app.env') == 'demo'): ?>
                                    <span class="help-block">Only Browser based option is enabled in demo.</span>
                                <?php endif; ?>

                            </div>
                        </div>

                            <div class="col-sm-4">
                                <div class="form-group">
                                    <?php echo Form::label('number_of_thermal_print_copy', __('printer.number_of_thermal_print_copy') . ':*'); ?>

                                    <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-share-alt"></i>
                                    </span>
                                        <input type="text" name="number_of_thermal_print_copy" class="form-control"
                                               placeholder="Enter Number of thermal print Copy"
                                               value="<?php echo e($location->number_of_thermal_print_copy, false); ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4" id="location_printer_div">
                                <div class="form-group">
                                    <?php echo Form::label('printer_id', __('printer.receipt_printers') . ':*'); ?>

                                    <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-share-alt"></i>
                                    </span>
                                        <?php echo Form::select('printer_id', $printers, $location->printer_id, ['class' => 'form-control select2', 'required']); ?>

                                    </div>
                                </div>
                            </div>
                            
                            <br/>

                            <div class="col-sm-4">
                                <div class="form-group">
                                    <?php echo Form::label('invoice_layout_id', __('invoice.invoice_layout') . ':*'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.invoice_layout') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
                                    <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-info"></i>
                                    </span>
                                        <?php echo Form::select('invoice_layout_id', $invoice_layouts, $location->invoice_layout_id, ['class' => 'form-control select2', 'required']); ?>

                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                            <div class="form-group">
                                <?php echo Form::label('invoice_scheme_id', __('invoice.invoice_scheme') . ':*'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.invoice_scheme') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-info"></i>
                                    </span>
                                    <?php echo Form::select('invoice_scheme_id', $invoice_schemes, $location->invoice_scheme_id, ['class' => 'form-control select2', 'required']); ?>

                                </div>
                            </div>
                        </div>




                        <div class="row">
                            <div class="col-sm-12">
                                <button class="btn btn-primary pull-right" type="submit"><?php echo app('translator')->get('messages.update'); ?></button>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
                <div class="tab-pane " id="tab_2">
                    <div class="row">
                        <div class="col-md-12">
                            <h4><?php echo e(__('messages.kitchen_stations'), false); ?>

                                <small><?php echo e(__('messages.feature_for_restaurant'), false); ?></small>
                            </h4>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-md-12">
                            <?php echo Form::open(['url' => route('location.settings_update', [$location->id]), 'method' => 'post', 'id' => 'bl_receipt_setting_form']); ?>

                            <div class="col-sm-4 margin-left-10">
                                <div class="form-group">
                                    <div class="checkbox icheck">
                                        <label>
                                            <input type="checkbox" name="is_active_kitchen_location" <?php echo e($location->is_active_kitchen_station == 1 ? 'checked' : '', false); ?>> <?php echo e(__('messages.enable_kitchen_station'), false); ?>

                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12" style="margin-top: 10px;padding-left: 0px;">
                                <div class="col-sm-5 form-group" style="padding-left: 0px;">
                                    <button class="btn btn-primary btn-modal" id="AddStation"><?php echo e(__('messages.add_station'), false); ?></button>
                                    <br><br><br><label><?php echo e(__('messages.enter_station_name'), false); ?></label>
                                </div>
                            </div>
                            <div class="col-sm-12" style="margin-top: 0px;padding-left: 0px;" id="StationDiv">
                                <?php if($location->kitchenStation()->count() < 1): ?>
                                <div class="col-sm-4 form-group" style="padding-left: 0px;display: flex" id="kitchenStation-0">
                                    <input type="text" name="station_name[]" class="form-control" placeholder="Station Name">
                                    <a class="removeStation" data-id="0"><i class="fa fa-trash text-danger margin-left-10"></i></a>
                                </div>

                                <?php else: ?>
                                    <?php $__currentLoopData = $kitchenStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kitchenStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4 form-group" style="padding-left: 0px;display: flex" id="kitchenStation-<?php echo e($kitchenStation->id, false); ?>">

                                        <input type="text" name="station_name_existing[<?php echo e($kitchenStation->id, false); ?>]" class="form-control" placeholder="Station Name" value="<?php echo e($kitchenStation->station_name, false); ?>">
                                        <a class="btn-delete" data-id="<?php echo e($kitchenStation->id, false); ?>"><i class="fa fa-trash text-danger margin-left-10"></i></a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                  <input type="hidden" name="deleted_station_name" class="form-control deleted_station_name" placeholder="deletedd Station Name"  >
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <button class="btn btn-primary pull-right" type="submit"><?php echo app('translator')->get('messages.update'); ?></button>
                                </div>
                            </div>
                            <div class="row">
                                <table class="table table-bordered table-striped  " role="grid">
                                    <thead>
                                        <tr>
                                            <th> <?php echo app('translator')->get('lang_v1.station_name'); ?></th>
                                             <th> <?php echo app('translator')->get('lang_v1.assign_unassign_categories'); ?> </th>
                                            <th>  <?php echo app('translator')->get('lang_v1.assigned_category_name'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($collectionKitchens): ?>
                                            <?php $__currentLoopData = $collectionKitchens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php $__currentLoopData = $kitchens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kitchenStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e($kitchenStation->station_name, false); ?></td>
                                                    <td>
                                                        <button data-href="/business-location/<?php echo e($kitchenStation->id, false); ?>/<?php echo e($location->id, false); ?>/assign_kitchen_categories" type="button" class="btn btn-outline-success mx-auto btn-lg assign_unassign_categories_button " > <?php echo app('translator')->get('lang_v1.assign_unassign_categories'); ?> <i class="fas fa-plus"></i></button>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $kitchenStation->kitchenCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kitchenCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <span class="badge badge-pill badge-info"><?php echo e($kitchenCategory->name, false); ?></span>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbovy>
                                </table>

                             </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
    </div>

    <div class="modal fade invoice_modal" tabindex="-1" role="dialog"
    	aria-labelledby="gridSystemModalLabel">
    </div>
    <div class="modal fade invoice_edit_modal" tabindex="-1" role="dialog"
        aria-labelledby="gridSystemModalLabel">
    </div>

    <div class="modal fade addKitchenCategoryModal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        let Id = 0;
        $(document).on('click','#AddStation', function(){
            Id = Id + 1;
            $('#StationDiv').append('<div class="col-sm-4 form-group" style="padding-left: 0px;display: flex" id="kitchenStation-'+ Id +'">\n' +
                '                                    <input type="text" name="station_name[]" class="form-control" placeholder="Station Name">\n' +
                '                                    <a class="btn-delete" data-id="'+ Id +'"><i class="fa fa-trash text-danger margin-left-10"></i></a>\n' +
                '                                </div>')
        });
        $(document).on('click','.removeStation', function(){
            let id = $(this).attr('data-id');
            $('#kitchenStation-'+id).remove();
        });
        $(document).on('click','.btn-delete', function(){
            let id = $(this).attr('data-id');
            $(this).closest('#kitchenStation-'+id).remove();

            let deleted_station_name = $('.deleted_station_name').val();
            $('.deleted_station_name').val(id);

            if((deleted_station_name)){
                $('.deleted_station_name').val(id + ',' + deleted_station_name);
            } else{
                $('.deleted_station_name').val(id );
            }

        });

        $(document).on('click', 'button.assign_unassign_categories_button', function() {
            $('div.addKitchenCategoryModal').load($(this).data('href'), function() {
                $(this).modal('show');
                $('form#assign_unassign_kitchen_form').submit(function(e) {

                    e.preventDefault();
                    $(this)
                        .find('button[type="submit"]')
                        .attr('disabled', true);
                    var data = new FormData($(this)[0]);

                    $.ajax({
                        method: 'POST',
                        url: $(this).attr('action'),
                        dataType: 'json',
                        data: data,
                        processData: false,
                        contentType: false,
                        success: function(result) {
                            if (result.success === true) {

                                $('div.addKitchenCategoryModal').modal('hide');
                                toastr.success(result.msg);
                                location . reload();

                            } else {
                                toastr.error(result.msg);
                            }
                        },
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/location_settings/index.blade.php ENDPATH**/ ?>