<div class="modal-dialog" role="document">
  <div class="modal-content">

    <?php echo Form::open(['url' => action('TaxonomyController@update', [$category->id]), 'method' => 'PUT', 'id' => 'category_edit_form', 'enctype' => 'multipart/form-data' ]); ?>


    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title"><?php echo app('translator')->get( 'messages.edit_category' ); ?></h4>
    </div>

    <div class="modal-body">
      <?php
        $name_label = !empty($module_category_data['taxonomy_label']) ? $module_category_data['taxonomy_label'] : __( 'category.category_name' );
        $cat_code_enabled = isset($module_category_data['enable_taxonomy_code']) && !$module_category_data['enable_taxonomy_code'] ? false : true;

        $cat_code_label = !empty($module_category_data['taxonomy_code_label']) ? $module_category_data['taxonomy_code_label'] : __( 'category.code' );

        $enable_sub_category = isset($module_category_data['enable_sub_taxonomy']) && !$module_category_data['enable_sub_taxonomy'] ? false : true;

        $category_code_help_text = !empty($module_category_data['taxonomy_code_help_text']) ? $module_category_data['taxonomy_code_help_text'] : __('lang_v1.category_code_help');
      ?>
      <div class="form-group">
        <?php echo Form::label('name', $name_label . ':*'); ?>

        <?php echo Form::text('name', $category->name, ['class' => 'form-control', 'required', 'placeholder' => $name_label]); ?>

      </div>
      <?php if($cat_code_enabled): ?>
      <div class="form-group">
        <?php echo Form::label('short_code', $cat_code_label . ':'); ?>

        <?php echo Form::number('short_code', $category->short_code, ['class' => 'form-control', 'placeholder' => $cat_code_label]); ?>

          <p class="help-block"><?php echo $category_code_help_text; ?></p>
      </div>
      <?php endif; ?>
      <div class="form-group">
        <?php echo Form::label('description', __( 'lang_v1.description' ) . ':'); ?>

        <?php echo Form::textarea('description', $category->description, ['class' => 'form-control', 'placeholder' => __( 'lang_v1.description'), 'rows' => 3]); ?>

      </div>

      <div class="row">
      <div class="col-md-6 col-lg-6 col-sm-12">
        <div class="form-group">
          <?php echo Form::label('category_image', __('messages.category_image') . ':'); ?>

          <?php echo Form::file('image', ['id' => 'edit_upload_image', 'accept' => 'image/*']); ?>

          <small><p class="help-block"><?php echo app('translator')->get('purchase.max_file_size', ['size' => (config('constants.document_size_limit') / 1000000)]); ?> </p></small>
        </div>
      </div>

        <div class="col-md-6 col-lg-6 col-sm-12">
          <div class="form-group">
            <div class="img-thumbnail">
              <?php if(!empty($category->image_path)): ?>
                <span class="badge bg-red delete-category-media" data-href="<?php echo e(action('TaxonomyController@deleteCategoryMedia', ['media_id' => $category->media->id]), false); ?>">
                 <i class="fa fa-close"></i>
                </span>
              <?php endif; ?>
              <img src="<?php echo e($category->image_url, false); ?>" class="display-thumbnail" width="60" height="60" id="editCategoryImagePreview" />
            </div>
          </div>
        </div>
      </div>

      <?php if(!empty($parent_categories) && $enable_sub_category): ?>
          <div class="form-group">
            <div class="checkbox">
              <label>
                 <?php echo Form::checkbox('add_as_sub_cat', 1, !$is_parent,[ 'class' => 'toggler', 'data-toggle_id' => 'parent_cat_div' ]); ?> <?php echo app('translator')->get( 'lang_v1.add_as_sub_txonomy' ); ?>
              </label>
            </div>
          </div>
          <div class="form-group <?php if($is_parent): ?> <?php echo e('hide', false); ?> <?php endif; ?>" id="parent_cat_div">
            <?php echo Form::label('parent_id', __( 'lang_v1.select_parent_taxonomy' ) . ':'); ?>

            <?php echo Form::select('parent_id', $parent_categories, $selected_parent, ['class' => 'form-control']); ?>

          </div>
      <?php endif; ?>
    </div>

    <div class="modal-footer">
      <button type="submit" class="btn btn-primary"><?php echo app('translator')->get( 'messages.update' ); ?></button>
      <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->get( 'messages.close' ); ?></button>
    </div>

    <?php echo Form::close(); ?>


  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog --><?php /**PATH /home/paneltech/panel/resources/views/taxonomy/edit.blade.php ENDPATH**/ ?>