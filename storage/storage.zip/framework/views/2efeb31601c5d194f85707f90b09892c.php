<?php $__env->startSection('title', __('lang_v1.sell_payment_report')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header no-print">
    <h1><?php echo e(__('lang_v1.sell_payment_report'), false); ?></h1>
</section>

<!-- Main content -->
<section class="content no-print">
    <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>
    <?php echo $__env->make('report.partials.report_list_filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.widget', ['class' => 'box-primary']); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped" id="sell_payment_report_table">
            <thead>
                <tr>
                    <th><?php echo app('translator')->get('messages.date'); ?></th>
                    <th><?php echo app('translator')->get('business.business_branch'); ?></th>
                    <th><?php echo app('translator')->get('sale.amount'); ?></th>
                    <th><?php echo app('translator')->get('lang_v1.payment_method'); ?></th>
                    <th><?php echo app('translator')->get('purchase.payment_status'); ?></th>
                    <th><?php echo app('translator')->get('client_app.client_app_name'); ?></th>
                </tr>
            </thead>
            <tfoot>
                <tr class="bg-gray font-17 footer-total text-center">
                    <td colspan="2" class="text-right"><strong><?php echo app('translator')->get('sale.total'); ?>:</strong></td>
                    <td class="text-left"><span class="display_currency" id="footer_total_amount"
                            data-currency_symbol="true"></span></td>
                    <td colspan="3"></td>
                </tr>
            </tfoot>
        </table>
    </div>
    <?php echo $__env->renderComponent(); ?>

</section>
<!-- /.content -->
<div class="modal fade view_register" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready(function() {



    //Date range as a button
    dateRangeSettings.startDate = moment().subtract(6, 'days');
    dateRangeSettings.endDate = moment();
    //dateRangeSettings.timePicker = true;



    $('#report_start_time, #report_end_time').datetimepicker({
        format: moment_time_format,
        ignoreReadonly: true,
    }).on('dp.change', function(ev) {
        sell_payment_report.ajax.reload();
    });
    $('#report_list_filter_date_range').daterangepicker(
        dateRangeSettings,
        function(start, end) {
            $('#report_list_filter_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(
                moment_date_format));
            sell_payment_report.ajax.reload();
        }
    );
    $('#report_list_filter_date_range').on('cancel.daterangepicker', function(ev, picker) {
        $('#report_list_filter_date_range').val('');
        sell_payment_report.ajax.reload();
    });

    $(document).on('change',
        '#report_list_filter_location_id, #report_list_filter_customer_id, #report_list_filter_payment_status, #report_list_filter_payment_method,#report_list_filter_client_app, #report_list_filter_created_by',
        function() {
            sell_payment_report.ajax.reload();
        });

    sell_payment_report = $('#sell_payment_report_table').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        aaSorting: [
            [1, 'desc']
        ],
        ajax: {
            url: '/reports/sell-payment-report',
            data: function(d) {
                var start = '';
                var end = '';
                var start_time = $('#report_start_time').val();
                var end_time = $('#report_end_time').val();
                if ($('#report_list_filter_date_range').val()) {
                    start = $('#report_list_filter_date_range').data('daterangepicker').startDate
                        .format('YYYY-MM-DD');

                    start = moment(start + " " + start_time, "YYYY-MM-DD" + " " +
                        moment_time_format).format('YYYY-MM-DD HH:mm');

                    end = $('#report_list_filter_date_range').data('daterangepicker').endDate
                        .format('YYYY-MM-DD');
                    end = moment(end + " " + end_time, "YYYY-MM-DD" + " " + moment_time_format)
                        .format('YYYY-MM-DD HH:mm');
                }
                d.start_date = start;
                d.end_date = end;
                d.location_id = $('#report_list_filter_location_id').val();
                d.customer_id = $('#report_list_filter_customer_id').val();
                d.payment_status = $('#report_list_filter_payment_status').val();
                d.payment_method = $('#report_list_filter_payment_method').val();
                d.client_app = $('#report_list_filter_client_app').val();
                d.created_by = $('#report_list_filter_created_by').val();

                d = __datatable_ajax_callback(d);
            }
        },
        columns: [{
                data: 'transaction_date',
                name: 'transaction_date',
                searchable: false
            },
            {
                data: 'business_location',
                name: 'bl.name'

            },
            {
                data: 'final_total',
                name: 'final_total',
                searchable: false
            },
            {
                data: 'payment_methods',
                name: 'payment_methods',
                orderable: false,
                searchable: false,
            },
            {
                data: 'payment_status',
                name: 'payment_status',
                searchable: false,
            },

            {
                data: 'client_app',
                orderable: false,
                searchable: false
            },
        ],
        fnDrawCallback: function(oSettings) {
            var total_amount = sum_table_col($('#sell_payment_report_table'), 'paid-amount');
            $('#footer_total_amount').text(total_amount);
            __currency_convert_recursively($('#sell_payment_report_table'));
        },
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/report/sell_payment_report.blade.php ENDPATH**/ ?>