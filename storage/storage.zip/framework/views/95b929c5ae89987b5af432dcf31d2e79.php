<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close no-print" data-dismiss="modal" aria-label="Close"><span
                    aria-hidden="true">&times;</span></button>
            <h4 class="modal-title text-center"><strong><?php echo app('translator')->get('sale.product'); ?>: </strong><?php echo e($recipe->variation->name, false); ?></h4>

        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-6">
                    <?php echo $recipe->variation->product->product_description; ?>

                </div>
                <div class="col-md-6">
                    <?php $__currentLoopData = $recipe->variation->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $media->thumbnail([60, 60], 'img-thumbnail'); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('manufacturing::lang.ingredient'); ?></th>
                                <th><?php echo app('translator')->get('lang_v1.quantity'); ?></th>
                                <th><?php echo app('translator')->get('lang_v1.price'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $ingredient_groups = [];
                            $ingredient_total_price = 0;
                            ?>
                            <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $ingredient_price =
                            $ingredient['quantity']*$ingredient['default_purchase_price']*$ingredient['multiplier'];
                            $ingredient_total_price += $ingredient_price;
                            ?>
                            <?php if(empty($ingredient['mfg_ingredient_group_id'])): ?>
                            <tr>
                                <td>
                                    <?php echo e($ingredient['full_name'], false); ?>

                                </td>
                                <td>
                                    <span class="display_currency"
                                        data-currency_symbol="false"><?php echo e(number_format($ingredient['quantity'], config('constants.quantity_precision', 2), session('currency')['decimal_separator'], session('currency')['thousand_separator']), false); ?></span>
                                    <?php echo e($ingredient['unit'], false); ?>

                                </td>

                                <td><span ><?php echo e(number_format($ingredient_price, config('constants.price_precision', 8), session('currency')['decimal_separator'], session('currency')['thousand_separator']), false); ?></span></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-right">
                                    <strong><?php echo app('translator')->get('manufacturing::lang.ingredients_cost'); ?></strong>
                                </td>
                                <td><span ><?php echo e(number_format($ingredient_total_price, config('constants.price_precision', 8), session('currency')['decimal_separator'], session('currency')['thousand_separator']), false); ?></span></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary no-print" aria-label="Print"
                onclick="$(this).closest('div.modal-content').printThis();"><i class="fa fa-print"></i> <?php echo app('translator')->get(
                'messages.print' ); ?>
            </button>
            <button type="button" class="btn btn-default no-print" data-dismiss="modal"><?php echo app('translator')->get( 'messages.close'
                ); ?></button>
        </div>
    </div>
</div>
<?php /**PATH /home/paneltech/panel/resources/views/product/recipe/modifier_show.blade.php ENDPATH**/ ?>