<?php $__env->startSection('title', __( 'restaurant.kitchen' )); ?>

<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content min-height-90hv no-print">

    <div class="row">
        <div class="col-md-12 text-center">
            <h3><?php echo app('translator')->get( 'restaurant.all_orders' ); ?> - <?php echo app('translator')->get( 'restaurant.kitchen' ); ?>
                <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('lang_v1.tooltip_kitchen') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></h3>
        </div>
    </div>


    <div class="box">
        <div class="box-header" style="display: flex;">
            <div>
                <label style="margin-right: 10px;font-size: 20px">Sorting</label>
                <button id="desc" value="desc" style="padding: 4px 10px"><i
                        class="fas fa-angle-down fa-2x"></i></button>
                <button id="asc" value="asc" style="padding: 4px 10px;"><i class="fa fa-angle-up fa-2x"></i></button>
            </div>
            <div style="margin-left: auto;">
                
                
                
                
                
                
                <select name="refresh_time" class="form-control select2" id="refresh_time">
                    <option value="">Manual Refresh</option>
                    <option value="1">1 Min Refresh</option>
                    <option value="2">2 Min Refresh</option>
                </select>
                <button type="button" class="btn btn-sm btn-primary pull-right" id="refresh_orders"
                    style="margin-left: 20px"><i class="fas fa-sync"></i> <?php echo app('translator')->get( 'restaurant.refresh' ); ?></button>
            </div>
        </div>
        <div class="box-body">
            <input type="hidden" id="orders_for" value="kitchen">
            <div class="row" id="orders_div">
                <?php echo $__env->make('restaurant.partials.show_orders', array('orders_for' => 'kitchen'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="overlay hide">
            <i class="fas fa-sync fa-spin"></i>
        </div>
    </div>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready(function() {
    $(document).on('click', 'a.mark_as_cooked_btn', function(e) {
        e.preventDefault();
        swal({
            title: LANG.sure,
            icon: "info",
            buttons: true,
        }).then((willDelete) => {
            if (willDelete) {
                var _this = $(this);
                var href = _this.data('href');
                $.ajax({
                    method: "GET",
                    url: href,
                    dataType: "json",
                    success: function(result) {
                        if (result.success == true) {
                            toastr.success(result.msg);
                            _this.closest('.order_div').remove();
                        } else {
                            toastr.error(result.msg);
                        }
                    }
                });
            }
        });
    });
});

$(document).ready(function() {
    $(document).on('click', 'a.mark_as_opened_btn', function(e) {
        e.preventDefault();
        var _this = $(this);
        _this.closest('.order_div').find('table').removeClass("bg-info");

    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.restaurant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/restaurant/kitchen/index.blade.php ENDPATH**/ ?>