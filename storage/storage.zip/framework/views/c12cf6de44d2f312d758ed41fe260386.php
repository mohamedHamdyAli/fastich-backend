<?php $__env->startSection('title', __('business.clientApp')); ?>




<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->get( 'client_app.client_app' ); ?>
        <small><?php echo app('translator')->get( 'client_app.manage_your_client_app' ); ?></small>
    </h1>
</section>

<!-- Main content -->
<section class="content">

    <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' => __( 'client_app.all_your_client_app' )]); ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_app.create')): ?>
    <?php $__env->slot('tool'); ?>
    <div class="box-tools">
        <p class="hide" style="color: #4169e1;">Note: <?php echo app('translator')->get( 'client_app.max_client_app' ); ?></p>
        <button type="button" class="btn btn-block btn-primary btn-modal"
            data-href="<?php echo e(action('ClientAppController@create'), false); ?>" data-container=".client_app_modal">
            <i class="fa fa-plus"></i> <?php echo app('translator')->get( 'messages.add' ); ?></button>
    </div>
    <?php $__env->endSlot(); ?>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_app.view')): ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped" id="client_app_table">
            <thead>
                <tr>
                    <th><?php echo app('translator')->get( 'client_app.client_name' ); ?></th>
                    <th><?php echo app('translator')->get( 'messages.action' ); ?></th>
                </tr>
            </thead>
        </table>
    </div>
    <?php endif; ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="modal fade client_app_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
    </div>


</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/client_app/index.blade.php ENDPATH**/ ?>