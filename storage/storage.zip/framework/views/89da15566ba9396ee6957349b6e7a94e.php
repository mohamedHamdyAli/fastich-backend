<!doctype html>
<html lang="<?php echo e(config('app.locale'), false); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonts -->
        <!-- <link href="https://fonts.googleapis.com/css?family=Raleway:100,300,600" rel="stylesheet" type="text/css"> -->

        <link rel="stylesheet" href="<?php echo e(asset('css/vendor.css'), false); ?>">

        <!-- Styles -->
        <style>
            body {
                min-height: 100vh;
                background-color: #006b82;
                color: #fff;
                background-image: url("https://panel.fastich.tech/img/bg.png");
            }
            .navbar-default {
                background-color: rgba(0, 75, 92, 0.5);
                border: none;
            }
            .navbar-static-top {
                margin-bottom: 19px;
            }
            .navbar-default .navbar-nav>li>a {
                color: #fff;
                font-weight: 600;
                font-size: 15px
            }
            .navbar-default .navbar-nav>li>a:hover{
                color: #ccc;
            }
            .navbar-default .navbar-brand {
                color: #ccc;
            }

            .homePic{

                text-align:center;



            }
            .homePic img{
                position: absolute;
                  margin: auto;
                  top: 0;
                  right: 0;
                  bottom: 0;
                  left: 0;
                  width: 600px;
                  height: 600px;

            }
        </style>
    </head>

    <body>
        <?php echo $__env->make('layouts.partials.home_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <div class="content">
                <!--
                <?php echo $__env->yieldContent('content'); ?>
                -->
                <br><br>

                <div class="homePic"><img src="https://panel.fastich.tech/img/mainPage.jpg" alt=""></div>



            </div>
        </div>
        <?php echo $__env->make('layouts.partials.javascripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/login.js?v=' . $asset_v), false); ?>"></script>
    <?php echo $__env->yieldContent('javascript'); ?>
    </body>
</html>
<?php /**PATH /home/paneltech/panel/resources/views/layouts/home.blade.php ENDPATH**/ ?>