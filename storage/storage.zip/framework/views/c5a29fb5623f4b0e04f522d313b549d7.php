<div class="modal-dialog" role="document">
    <div class="modal-content">
        <?php echo Form::open(['url' => action('TaxonomyController@addCategoryLocations', [$category_id]), 'method' => 'POST', 'id' => 'assign_unassign_form', 'enctype' => 'multipart/form-data' ]); ?>

            <div class="modal-header">
              <h3 class="modal-title" id="exampleModalLongTitle">  <?php echo app('translator')->get('lang_v1.assign_unassign_locations'); ?> </h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            <?php echo Form::hidden('categoryID', $category_id, ['class' => 'form-control']); ?>

            <?php echo Form::select('locations_ids[]', $locations_dropdown,  $category_locations_ids, ['class' => 'form-control select2 ', 'multiple', 'id' => 'locations_ids']); ?>

            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('lang_v1.save_changes'); ?></button>
              <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->get( 'messages.close' ); ?></button>
            </div>
          </div>
        <?php echo Form::close(); ?>

      </div>
  </div>
<script src="<?php echo e(asset('js/app.js?v=' . $asset_v), false); ?>"></script>
<?php /**PATH /home/paneltech/panel/resources/views/taxonomy/modifiers/add_locations_modal.blade.php ENDPATH**/ ?>