<?php $__env->startSection('title', __('stock_adjustment.stock_adjustments')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->get('stock_adjustment.stock_adjustments'); ?>
        <small></small>
    </h1>
</section>
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>
            <?php echo Form::open(['url' => action('StockAdjustmentController@index'), 'method' => 'get', 'id' =>
            'stock_adjustments_form' ]); ?>

            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('search_product', __('lang_v1.search_product') . ':'); ?>

                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="fa fa-search"></i>
                        </span>
                        <input type="hidden" value="" id="variation_id">
                        <?php echo Form::text('search_product', null, ['class' => 'form-control', 'id' => 'search_product',
                        'placeholder' => __('lang_v1.search_product_placeholder'), 'autofocus']); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-3" id="location_filter">
                <div class="form-group">
                    <?php echo Form::label('location_id', __('purchase.business_location') . ':'); ?>

                    <?php echo Form::select('location_id', $business_locations, null, ['class' => 'form-control select2',
                    'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('category_id', __('product.category') . ':'); ?>

                    <?php echo Form::select('category_id', $categories, null, ['class' => 'form-control select2', 'style' =>
                    'width:100%', 'id' => 'product_list_filter_category_id', 'placeholder' => __('lang_v1.all')]); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo Form::label('adjustment_type', __('stock_adjustment.adjustment_type') . ':'); ?>

                    <?php echo Form::select('adjustment_type', [ 'normal' =>
                    __('stock_adjustment.normal'), 'abnormal' =>
                    __('stock_adjustment.abnormal'),'wastage' => __('stock_adjustment.wastage'), 'damage' =>
                    __('stock_adjustment.damage'),'shortage' => __('stock_adjustment.shortage')], null,
                    ['class' =>'form-control select2' , 'placeholder' => __('lang_v1.all')] ); ?>

                </div>
            </div>

            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('stock_adjustment_list_filter_date', __('report.date_range') . ':'); ?>

                    <?php echo Form::text('stock_adjustment_list_filter_date', null, ['placeholder' =>
                    __('lang_v1.select_a_date_range'), 'class'
                    => 'form-control', 'readonly']); ?>

                </div>
            </div>
            <div class="col-md-3 form-group">
                <?php echo Form::label('stock_adjustment_list_start_time', __('lang_v1.time_range') . ':'); ?>

                <?php
                $startDay = Carbon::now()->startOfDay();
                $endDay = $startDay->copy()->endOfDay();
                ?>
                <div class="input-group">
                    <?php echo Form::text('start_time', \Carbon::createFromTimestamp(strtotime($startDay))->format('H:i'), ['class' =>'form-control width-50', 'id' =>
                    'stock_adjustment_list_start_time']); ?>

                    <?php echo Form::text('end_time', \Carbon::createFromTimestamp(strtotime($endDay))->format('H:i'), ['class' => 'form-control width-50', 'id' =>
                    'stock_adjustment_list_end_time']); ?>

                </div>
            </div>
            <?php echo Form::close(); ?>

            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' => __('stock_adjustment.all_stock_adjustments')]); ?>
    <?php $__env->slot('tool'); ?>
    <div class="box-tools">
        <a class="btn btn-block btn-primary" href="<?php echo e(action('StockAdjustmentController@create'), false); ?>">
            <i class="fa fa-plus"></i> <?php echo app('translator')->get('messages.add'); ?></a>
    </div>
    <?php $__env->endSlot(); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped ajax_view" id="stock_adjustment_table">
            <thead>
                <tr>
                    <th><?php echo app('translator')->get('messages.action'); ?></th>
                    <th><?php echo app('translator')->get('messages.date'); ?></th>
                    <th><?php echo app('translator')->get('purchase.ref_no'); ?></th>
                    <th><?php echo app('translator')->get('business.location'); ?></th>
                    <th><?php echo app('translator')->get('stock_adjustment.adjustment_type'); ?></th>
                    <th><?php echo app('translator')->get('stock_adjustment.total_amount'); ?></th>
                    <th><?php echo app('translator')->get('stock_adjustment.total_amount_recovered'); ?></th>
                    <th><?php echo app('translator')->get('stock_adjustment.reason_for_stock_adjustment'); ?></th>
                    <th><?php echo app('translator')->get('lang_v1.added_by'); ?></th>
                </tr>
            </thead>
        </table>
    </div>
    <?php echo $__env->renderComponent(); ?>

</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/stock_adjustment.js?v=' . $asset_v), false); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/stock_adjustment/index.blade.php ENDPATH**/ ?>