<div class="modal-dialog" role="document">
    <div class="modal-content">

        <?php echo Form::open(['url' => action('ClientAppController@update', [$client_app->id]), 'method' => 'PUT', 'id' =>
        'client_app_edit_form' ]); ?>


        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                    aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><?php echo app('translator')->get( 'client_app.edit_client_app' ); ?></h4>
        </div>

        <div class="modal-body">
            <div class="form-group">
                <?php echo Form::label('app_name', __( 'client_app.name' ) . ':*'); ?>

                <?php echo Form::text('app_name', $client_app->app_name, ['class' => 'form-control', 'required', 'placeholder'
                =>
                __(
                'client_app.name' )]); ?>

            </div>

        </div>

        <div class="modal-footer">
            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get( 'messages.update' ); ?></button>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->get( 'messages.close' ); ?></button>
        </div>

        <?php echo Form::close(); ?>


    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
<?php /**PATH /home/paneltech/panel/resources/views/client_app/edit.blade.php ENDPATH**/ ?>