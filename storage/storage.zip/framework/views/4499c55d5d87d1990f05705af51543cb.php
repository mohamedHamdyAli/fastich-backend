<div class="modal-dialog modal-lg product-modifier-modal" role="document">
    <div class="modal-content">

        <?php echo Form::open(['url' => action('Restaurant\ModifierSetsController@update', [$modifer_set->id]), 'method' => 'PUT', 'id' => 'edit_form' ]); ?>


        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><?php echo app('translator')->get( 'restaurant.edit_modifier' ); ?></h4>
        </div>

        <div class="modal-body">

            <div class="row">

                <div class="col-sm-12">
                    <div class="form-group">
                        <?php echo Form::label('name', __( 'restaurant.modifier_set' ) . ':*'); ?>

                        <?php echo Form::text('name', $modifer_set->name, ['class' => 'form-control', 'required', 'placeholder' => __( 'lang_v1.name' ) ]); ?>

                    </div>
                </div>

                <div class="col-sm-12">
                    <h4><?php echo app('translator')->get( 'restaurant.modifiers' ); ?></h4>
                </div>

                <div class="col-sm-12">
                    <table class="table table-condensed" id="add-modifier-table">
                        <thead>
                        <tr>
                            <th><?php echo app('translator')->get( 'restaurant.modifier'); ?></th>
                            <th>
                                <?php echo app('translator')->get( 'lang_v1.price'); ?>

                                <?php
                                    $html = '<tr><td>
                                          <div class="form-group">
                                            <input type="text" name="modifier_name[]" 
                                            class="form-control" 
                                            placeholder="' . __( 'lang_v1.name' ) . '" required>
                                          </div>
                                        </td>
                                        <td>
                                          <div class="form-group">
                                            <input type="text" name="modifier_price[]" class="form-control input_number" 
                                            placeholder="' . __( 'lang_v1.price' ) . '" required>
                                          </div>
                                        </td>
                                        <td>
                                          <button class="btn btn-danger btn-xs pull-right remove-modifier-row" type="button"><i class="fa fa-minus"></i></button>
                                        </td>
                                        </tr>';
                                ?>
                            </th>
                            <th><?php echo app('translator')->get( 'restaurant.tax'); ?></th>
                            <th><?php echo app('translator')->get( 'restaurant.tax_type'); ?></th>
                            <th><?php echo app('translator')->get( 'restaurant.price_inc_tax'); ?></th>
                            <th>&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $modifer_set->variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modifier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <input type="text" name="modifier_name_edit[<?php echo e($modifier->id, false); ?>]"
                                               class="form-control" value="<?php echo e($modifier->name, false); ?>"
                                               placeholder="<?php echo app('translator')->get( 'lang_v1.name' ); ?>"
                                               required>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <input type="text" name="modifier_price_edit[<?php echo e($modifier->id, false); ?>]"
                                               class="form-control input_number modifier-price-edit"
                                               value="<?php echo e($modifier->default_sell_price, false); ?>"
                                               placeholder="<?php echo app('translator')->get( 'lang_v1.price' ); ?>" required>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <select name="modifier_tax_edit[<?php echo e($modifier->id, false); ?>]"
                                                class="form-control select2 modifier-tax-edit">
                                            <option value="">Please Select</option>
                                            <?php $__currentLoopData = $taxRates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxRate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-amount="<?php echo e($taxRate['amount'], false); ?>"
                                                        value="<?php echo e($taxRate['id'], false); ?>" <?php echo e(($modifier->tax_id == $taxRate['id']) ? 'selected' : '', false); ?> ><?php echo e($taxRate['name'], false); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <select name="modifier_tax_type_edit[<?php echo e($modifier->id, false); ?>]"
                                                class="form-control select2 modifier-tax-type-edit">
                                            <option value="exclusive" <?php echo e(($modifier->tax_type == 'exclusive') ? 'selected' : '', false); ?>>
                                                Exclusive
                                            </option>
                                            <option value="inclusive" <?php echo e(($modifier->tax_type == 'inclusive') ? 'selected' : '', false); ?>>
                                                Inclusive
                                            </option>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <input type="text" value="<?php echo e(number_format($modifier->sell_price_inc_tax, 2), false); ?>"
                                               name="modifier_price_inc_tax_edit[<?php echo e($modifier->id, false); ?>]"
                                               class="form-control modifier-price-inc-tax-edit input_number"
                                               required/>
                                    </div>
                                </td>
                                <td>
                                    <?php if(!$loop->first): ?>
                                        <button class="btn btn-danger btn-xs pull-right remove-modifier-row"
                                                type="button"><i
                                                    class="fa fa-minus"></i></button>
                                    <?php else: ?>
                                        <button class="btn btn-primary btn-xs pull-right add-modifier-row-edit"
                                                type="button">
                                            <i class="fa fa-plus"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo app('translator')->get( 'messages.update' ); ?></button>
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->get( 'messages.close' ); ?></button>
            </div>

            <?php echo Form::close(); ?>


        </div><!-- /.modal-content -->
    </div>
</div>
<!-- /.modal-dialog -->
<?php /**PATH /home/paneltech/panel/resources/views/restaurant/modifier_sets/edit.blade.php ENDPATH**/ ?>