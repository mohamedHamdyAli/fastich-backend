<!-- Modal -->
<div class="modal fade addIngredintModal" id="addIngredintModal" tabindex="-1" role="dialog"
    aria-labelledby="addModifiersModalTitle" aria-hidden="false">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <!-- Content Header (Page header) -->
                <h3 class="modal-title" id="exampleModalLongTitle"> <?php echo app('translator')->get('manufacturing::lang.add_ingredients'); ?> </h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Main content -->
                <section class="content">
                    <div id="box_group">
                        <div class="box box-solid">
                            <div class="box-header">
                                <h4 class="box-title"><strong><?php echo app('translator')->get('sale.product'); ?>:
                                    </strong><?php echo e($variation->product_name, false); ?> <?php if($variation->product_type == 'variable'): ?> -
                                    <?php echo e($variation->product_variation_name, false); ?> - <?php echo e($variation->name, false); ?> <?php endif; ?></h4>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-10 col-md-offset-1">
                                        <div class="form-group">
                                            <?php echo Form::label('search_product',
                                            __('manufacturing::lang.select_ingredient').':'); ?>


                                            <?php echo Form::text('search_product', null, ['class' => 'form-control', 'id' =>
                                            'search_product', 'placeholder' =>
                                            __('manufacturing::lang.select_ingredient'), 'autofocus' => true ]); ?>


                                            <?php echo Form::hidden('variation_id', $variation->id, ['id' => 'variation_id']); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <table class="table table-striped table-th-green text-center ingredients_table">
                                            <thead>
                                                <tr>
                                                    <th><?php echo app('translator')->get('manufacturing::lang.ingredient'); ?></th>
                                                    <th><?php echo app('translator')->get('manufacturing::lang.final_quantity'); ?></th>
                                                    <th><?php echo app('translator')->get('lang_v1.price'); ?></th>
                                                    <th>&nbsp;</th>
                                                </tr>
                                            </thead>
                                            <tbody class="ingredient-row-sortable">
                                                <?php
                                                $row_index = 0;
                                                $ingredient_groups = [];
                                                $ingredient_total = 0;
                                                ?>
                                                <?php if(!empty($ingredients)): ?>
                                                <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                $ingredient_obj = (object) $ingredient;
                                                $price = !empty($ingredient_obj->quantity) ? $ingredient_obj->quantity *
                                                $ingredient_obj->default_purchase_price : $ingredient_obj->default_purchase_price;
                                                $price = $price * $ingredient_obj->multiplier;
                                                $ingredient_total += $price;
                                                ?>
                                                <?php if(empty($ingredient['mfg_ingredient_group_id'])): ?>
                                                <?php
                                                $row_index = $loop->index;
                                                ?>

                                                <?php echo $__env->make('product.recipe.ingredient_row', ['ingredient' => (object)
                                                $ingredient, 'ig_index' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                <?php
                                                $row_index++;
                                                ?>
                                                <?php else: ?>
                                                <?php
                                                $ingredient_groups[$ingredient['mfg_ingredient_group_id']][] =
                                                $ingredient;
                                                ?>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--box end-->
                        <?php
                        $ig_index = 0;
                        ?>
                        <?php $__currentLoopData = $ingredient_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $ig_name = !empty($ingredient_group[0]['ingredient_group_name']) ?
                        $ingredient_group[0]['ingredient_group_name'] : '';
                        $ig_description = !empty($ingredient_group[0]['ig_description']) ?
                        $ingredient_group[0]['ig_description'] : '';
                        ?>
                        <?php echo $__env->make('product.recipe.ingredient_group', ['ingredients' => $ingredient_group, 'ig_index' =>
                        $ig_index, 'ig_name' => $ig_name, 'ig_description' => $ig_description], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php
                        $ig_index++;
                        $row_index += count($ingredient_group);
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="box box-solid">
                        <div class="box-body">
                            <div class="row">
                                <input type="hidden" id="row_index" value="<?php echo e($row_index, false); ?>">
                                <input type="hidden" id="ig_index" value="<?php echo e($ig_index, false); ?>">
                                <div class="col-md-6 text-center">
                                    <label>
                                        <input type="checkbox" class="row-select" value="" id="update_product_purchase_price">
                                        <?php echo app('translator')->get('lang_v1.update_product_purchase_rice'); ?>
                                    </label>
                                </div>
                                 <div class="col-md-6 text-center">
                                    <strong><?php echo app('translator')->get('manufacturing::lang.ingredients_cost'); ?>: </strong> <span
                                        id="ingredients_cost_text"><?php echo e(number_format($ingredient_total, config('constants.currency_precision', 2), session('currency')['decimal_separator'], session('currency')['thousand_separator']), false); ?></span>
                                    <input type="hidden" name="total_ingredients_cost" id="ingredients_cost"
                                        value="<?php echo e($recipe->ingredients_cost ?? 0, false); ?>">
                                </div>

                            </div>
                        </div>
                    </div>

                </section>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"> <?php echo app('translator')->get('lang_v1.close'); ?> </button>
                <button type="button" class="btn btn-primary pull-right"
                    id="save_recipe"><?php echo app('translator')->get('messages.save'); ?></button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/paneltech/panel/resources/views/product/recipe/add_ingredients.blade.php ENDPATH**/ ?>