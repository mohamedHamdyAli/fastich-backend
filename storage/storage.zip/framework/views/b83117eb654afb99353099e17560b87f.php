<?php $__env->startSection('title', __('role.add_role')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->get('role.add_role'); ?></h1>
</section>

<!-- Main content -->
<section class="content">
    <?php $__env->startComponent('components.widget', ['class' => 'box-primary']); ?>
    <?php echo Form::open(['url' => action('RoleController@store'), 'method' => 'post', 'id' => 'role_add_form']); ?>

    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <?php echo Form::label('name', __('user.role_name') . ':*'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control', 'required', 'placeholder' =>
                __('user.role_name')]); ?>

            </div>

        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <h2><?php echo app('translator')->get('user.permissions'); ?>:</h2>
        </div>
    </div>
    <hr>
    
    <?php if(in_array('service_staff_module', $enabled_modules)): ?>
    <div class="row">
        <div class="col-md-2">
            <h4><?php echo app('translator')->get('lang_v1.user_type'); ?></h4>
        </div>
        <div class="col-md-9 col-md-offset-1">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('is_service_staff', 1, false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('restaurant.service_staff'), false); ?>

                    </label>
                    <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('restaurant.tooltip_service_staff') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('user_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.user'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'user.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.user.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'user.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.user.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'user.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.user.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'user.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.user.delete'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('user_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('user.roles'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'roles.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.view_role'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'roles.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.add_role'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'roles.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.edit_role'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'roles.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.delete_role'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('supplier_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.supplier'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'supplier.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.view_all_supplier'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'supplier.view_own', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.view_own_supplier'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'supplier.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.supplier.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'supplier.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.supplier.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'supplier.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.supplier.delete'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('customer_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.customer'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'customer.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.view_all_customer'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'customer.view_own', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.view_own_customer'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'customer.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.customer.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'customer.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.customer.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'customer.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.customer.delete'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('product_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('business.product'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'product.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.product.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'product.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.product.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'product.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.product.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'product.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.product.delete'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'product.add_recipe', false, ['class' => 'input-icheck']); ?> <?php echo e(__('lang_v1.add_recipe'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'product.import_products', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('lang_v1.import_products'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'product.opening_stock', false, ['class' => 'input-icheck']); ?> <?php echo e(__('lang_v1.add_opening_stock'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'product.view_purchase_price', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('lang_v1.view_purchase_price'), false); ?>

                    </label>
                    <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('lang_v1.view_purchase_price_tooltip') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('product_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.unit'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'unit.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.unit.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'unit.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.unit.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'unit.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.unit.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'unit.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.unit.delete'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('product_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('category.category'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'category.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.category.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'category.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.category.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'category.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.category.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'category.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.category.delete'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('product_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('lang_v1.modifiers'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'modifiers.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.modifier.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'modifiers.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.modifier.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'modifiers.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.modifier.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'modifiers.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.modifier.delete'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('purchasing_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.purchase'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.purchase.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.purchase.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.purchase.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.purchase.delete'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.return', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.purchase.return'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.update_status', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('lang_v1.update_status'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.view_own_purchase', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('lang_v1.view_own_purchase'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.payments.add', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.purchase.payments.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.payments.edit', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.purchase.payments.edit'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase.payments.delete', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.purchase.payments.delete'), false); ?>

                    </label>
                </div>
            </div>

        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('inventory_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.stock'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.add_edit_opening_stock', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.stock.add_edit_opening_stock'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.import_opening_stock', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.stock.import_opening_stock'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.adjustment.view', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.stock.adjustment.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.adjustment.add', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.stock.adjustment.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.adjustment.edit', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.stock.adjustment.edit'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.adjustment.delete', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.stock.adjustment.delete'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.adjustment.view_own_only', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.stock.adjustment.view_own_only'), false); ?>

                    </label>
                </div>
            </div>

            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.transfer.view', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.stock.transfer.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.transfer.add', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.stock.transfer.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.transfer.edit', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.stock.transfer.edit'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.transfer.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.stock.transfer.delete'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock.transfer.view_own_only', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.stock.transfer.view_own_only'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('point_of_sales_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.pos_sale'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.pos.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.view_branch_sell', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.sell.pos.view_branch_sell'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.add', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.pos.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.edit', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.pos.edit'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.edit_branch_sell', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.sell.pos.edit_branch_sell'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.return', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.pos.return'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.edit_product_price_from_pos_screen', false,
                        ['class' => 'input-icheck']); ?> <?php echo e(__('role.sell.pos.edit_product_price_from_pos_screen'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.add_product_discount_from_pos_screen', false,
                        ['class' => 'input-icheck']); ?> <?php echo e(__('role.sell.pos.add_product_discount_from_pos_screen'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.customer.add', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.pos.customer.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.view_cash_register', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.sell.pos.view_cash_register'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.pos.close_cash_register', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.sell.pos.close_cash_register'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('point_of_sales_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.bpos_sale'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.bpos.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.view_branch_sell', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.sell.bpos.view_branch_sell'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.add', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.bpos.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.edit', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.bpos.edit'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.edit_branch_sell', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.sell.bpos.edit_branch_sell'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.return', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.bpos.return'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.edit_product_price_from_pos_screen', false,
                        ['class' => 'input-icheck']); ?> <?php echo e(__('role.sell.bpos.edit_product_price_from_pos_screen'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.add_product_discount_from_pos_screen', false,
                        ['class' => 'input-icheck']); ?> <?php echo e(__('role.sell.bpos.add_product_discount_from_pos_screen'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.customer.add', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.sell.bpos.customer.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.view_cash_register', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.sell.bpos.view_cash_register'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.bpos.close_cash_register', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.sell.bpos.close_cash_register'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>


    
    <?php if(in_array('direct_sales_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.direct_sale'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.add', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.edit', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.edit'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.return', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.return'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.add_quotation', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.sell.add_quotation'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.list_quotations', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.sell.list_quotations'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.list_drafts', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.list_drafts'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.access_types_of_service', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.sell.access_types_of_service'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.access_shipping', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.access_shipping'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.payments', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.payments'), false); ?>

                    </label>
                    
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.add_edit_subscription', false, ['class' =>
                        'input-icheck']); ?>

                        <?php echo e(__('role.sell.add_edit_subscription'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.delete_subscription', false, [
                        'class' => 'input-icheck',
                        ]); ?>

                        <?php echo e(__('role.sell.delete_subscription'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('direct_sales_module', $enabled_modules) || in_array('point_of_sales_module', $enabled_modules) ||
    in_array('barcode_pos', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.sale_manager'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.view_all', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.view_all'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sell.import_sales', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.sell.import_sales'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('offer_discount_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.discounts'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'discount.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.discount.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'discount.add', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.discount.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'discount.edit', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.discount.edit'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'discount.activate_deactivate', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.discount.activate_deactivate'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <?php if(in_array('expenses_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.expenses'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.expense.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.add', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.expense.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.edit', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.expense.edit'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.expense.delete'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.payment.add', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.expense.payment.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.payment.view', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.expense.payment.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.view_own_expense', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.expense.view_own_expense'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.category.add', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.expense.category.add'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.category.edit', false, ['class' => 'input-icheck']); ?> <?php echo e(__('role.expense.category.edit'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('cash_register.cash_register'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'view_cash_register', false, ['class' => 'input-icheck']); ?> <?php echo e(__('lang_v1.view_cash_register'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'close_cash_register', false, ['class' => 'input-icheck']); ?> <?php echo e(__('lang_v1.close_cash_register'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>

    
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.brand'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'brand.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.brand.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'brand.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.brand.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'brand.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.brand.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'brand.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.brand.delete'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>

    
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.tax_rate'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'tax_rate.view', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.tax_rate.view'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'tax_rate.create', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.tax_rate.create'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'tax_rate.update', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.tax_rate.update'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'tax_rate.delete', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.tax_rate.delete'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get( 'role.report' ); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__( 'role.select_all' ), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <?php if(in_array('purchasing_module', $enabled_modules) ||
            in_array('direct_sales_module', $enabled_modules) ||
            in_array('point_of_sales_module', $enabled_modules)): ?>

            <?php if(in_array('product_module', $enabled_modules) ): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.product_sell.view',
                        in_array('report.product_sell.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.product_sell.view' ), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.product_purchase.view',
                        in_array('report.product_purchase.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.product_purchase.view' ), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.item.view',
                        in_array('report.item.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.item.view' ), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'view_product_stock_value',
                        in_array('view_product_stock_value', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'lang_v1.view_product_stock_value' ), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'trending_product_report.view',
                        in_array('trending_product_report.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.trending_product_report.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <?php if(in_array('purchasing_module', $enabled_modules) ): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.purchase_payment.view',
                        in_array('report.purchase_payment.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.purchase_payment.view' ), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'purchase_n_sell_report.view',
                        in_array('purchase_n_sell_report.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.purchase_n_sell_report.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.sell_payment.view',
                        in_array('report.sell_payment.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.sell_payment.view' ), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.sell_by_branch.view',
                        in_array('report.sell_by_branch.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.sell_by_branch.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'tax_report.view', in_array('tax_report.view',
                        $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.tax_report.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php if(in_array('customer_module', $enabled_modules)): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'contacts_report.view', in_array('contacts_report.view',
                        $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.contacts_report.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <?php if(in_array('supplier_module', $enabled_modules)): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.supplier.view', in_array('report.supplier.view',
                        $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.supplier.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <?php if(in_array('loyalty_module', $enabled_modules)): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'sales_representative.view',
                        in_array('sales_representative.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.sales_representative.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <?php if(in_array('table_module', $enabled_modules)): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.table.view', in_array('report.table.view',
                        $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.table.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <?php if(in_array('service_staff_module', $enabled_modules)): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'report.service_staff.view',
                        in_array('report.service_staff.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.report.service_staff.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <?php if(in_array('expenses_module', $enabled_modules)): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense_report.view', in_array('expense_report.view',
                        $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.expense_report.view' ), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'profit_loss_report.view',
                        in_array('profit_loss_report.view', $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.profit_loss_report.view' ), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'stock_report.view', in_array('stock_report.view',
                        $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.stock_report.view' ), false); ?>

                    </label>
                </div>
            </div>


            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'register_report.view', in_array('register_report.view',
                        $role_permissions),
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__( 'role.register_report.view' ), false); ?>

                    </label>
                </div>
            </div>


        </div>
    </div>
    <hr>
    
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('role.settings'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'business_settings.access', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.business_settings.access'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'barcode_settings.access', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.barcode_settings.access'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'invoice_settings.access', false, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('role.invoice_settings.access'), false); ?>

                    </label>
                </div>
            </div>
            <?php if(in_array('expenses_module', $enabled_modules)): ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'expense.access', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.expense.access'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'view_own_expense', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.view_own_expense'), false); ?>

                    </label>
                </div>
            </div>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'access_printers', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.access_printers'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'superadmin.access_package_subscriptions',false,
                        [ 'class' => 'input-icheck']); ?> <?php echo e(__('superadmin::lang.access_package_subscriptions'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    
    <div class="row check_group">
        <div class="col-md-3">
            <h4><?php echo app('translator')->get('role.dashboard'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true"
                    data-container="body" data-toggle="popover" data-placement="auto bottom"
                    data-content="' . __('tooltip.dashboard_permission') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></h4>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'dashboard.data', true, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('role.dashboard.data'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    
    <div class="row check_group">
        <div class="col-md-3">
            <h4><?php echo app('translator')->get('account.account'); ?></h4>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'account.access', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.access_accounts'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    
    <?php if(in_array('table_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get('restaurant.bookings'); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__('role.select_all'), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'crud_all_bookings', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('restaurant.add_edit_view_all_booking'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'crud_own_bookings', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('restaurant.add_edit_view_own_booking'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-3">
            <h4><?php echo app('translator')->get('lang_v1.access_selling_price_groups'); ?></h4>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'access_default_selling_price', true, ['class' =>
                        'input-icheck']); ?> <?php echo e(__('lang_v1.default_selling_price'), false); ?>

                    </label>
                </div>
            </div>
            <?php if(count($selling_price_groups) > 0): ?>
            <?php $__currentLoopData = $selling_price_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selling_price_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('spg_permissions[]', 'selling_price_group.' . $selling_price_group->id,
                        false, [
                        'class' => 'input-icheck',
                        ]); ?> <?php echo e($selling_price_group->name, false); ?>

                    </label>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <hr>
    <?php if(in_array('table_module', $enabled_modules)): ?>
    <div class="row">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get( 'role.table' ); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__( 'role.select_all' ), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'access_tables', false, ['class' => 'input-icheck']); ?>

                        <?php echo e(__('lang_v1.access_tables'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <hr>
    <?php if(in_array('kitchen_module', $enabled_modules)): ?>
    <div class="row check_group">
        <div class="col-md-1">
            <h4><?php echo app('translator')->get( 'role.kitchen_screen' ); ?></h4>
        </div>
        <div class="col-md-2">
            <div class="checkbox">
                <label>
                    <input type="checkbox" class="check_all input-icheck"> <?php echo e(__( 'role.select_all' ), false); ?>

                </label>
            </div>
        </div>
        <div class="col-md-9">
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'access_kitchen_screen', false,
                        ['class' =>'input-icheck']); ?>

                        <?php echo e(__('role.access_kitchen_screen'), false); ?>

                    </label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('permissions[]', 'access_kitchen_order', false,
                        [ 'class' => 'input-icheck']); ?>

                        <?php echo e(__('role.access_kitchen_order'), false); ?>

                    </label>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!--  <?php echo $__env->make('role.partials.module_permissions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
    <div class="row">
        <div class="col-md-12">
            <button type="submit" class="btn btn-primary pull-right"><?php echo app('translator')->get('messages.save'); ?></button>
        </div>
    </div>

    <?php echo Form::close(); ?>

    <?php echo $__env->renderComponent(); ?>
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/role/create.blade.php ENDPATH**/ ?>