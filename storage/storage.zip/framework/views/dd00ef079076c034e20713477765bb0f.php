<?php $__env->startSection('title', __( 'report.stock_adjustment_report' )); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->get( 'report.stock_adjustment_report' ); ?>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>
        <?php echo Form::open(['url' => action('StockAdjustmentController@index'), 'method' => 'get', 'id' =>
        'stock_adjustments_form' ]); ?>

        <div class="col-md-3 col-xs-6">
            <div class="form-group">
                <?php echo Form::label('search_product', __('lang_v1.search_product') . ':'); ?>

                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-search"></i>
                    </span>
                    <input type="hidden" value="" id="variation_id">
                    <?php echo Form::text('search_product', null, ['class' => 'form-control', 'id' => 'search_product',
                    'placeholder' => __('lang_v1.search_product_placeholder'), 'autofocus']); ?>

                </div>
            </div>
        </div>
        <div class="col-md-3 col-xs-6 hide">
            <div class="form-group">
                <?php echo Form::label('location_id_old', __('purchase.business_location') . ':'); ?>

                <div class="input-group">
                    <span class="input-group-addon bg-light-blue"><i class="fa fa-map-marker"></i></span>
                    <select class="form-control select2" id="location_id_old">
                        <?php $__currentLoopData = $business_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key, false); ?>"><?php echo e($value, false); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <?php echo Form::label('location_id', __('purchase.business_location') . ':'); ?>

                <?php echo Form::select('location_id', $business_locations, null, ['class' => 'form-control select2',
                'style' => 'width:100%']); ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('adjustment_type', __('stock_adjustment.adjustment_type') . ':'); ?>

                <?php echo Form::select('adjustment_type', [ 'normal' =>
                __('stock_adjustment.normal'), 'abnormal' =>
                __('stock_adjustment.abnormal'),'wastage' => __('stock_adjustment.wastage'), 'damage' =>
                __('stock_adjustment.damage'),'shortage' => __('stock_adjustment.shortage')], null,
                ['class' =>'form-control select2' , 'placeholder' => __('lang_v1.all')] ); ?>

            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <?php echo Form::label('stock_adjustment_list_filter_date', __('report.date_range') . ':'); ?>

                <?php echo Form::text('stock_adjustment_list_filter_date', null, ['placeholder' =>
                __('lang_v1.select_a_date_range'), 'class'
                => 'form-control', 'readonly']); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>

        <?php echo $__env->renderComponent(); ?>
    </div>
    <br>
    <div class="row">
        <div class="col-sm-6">
            <?php $__env->startComponent('components.widget'); ?>
            <table class="table no-border">
                <tr>
                    <th><?php echo e(__('report.total_normal'), false); ?>:</th>
                    <td>
                        <span class="total_normal">
                            <i class="fas fa-sync fa-spin fa-fw"></i>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th><?php echo e(__('report.total_abnormal'), false); ?>:</th>
                    <td>
                        <span class="total_abnormal">
                            <i class="fas fa-sync fa-spin fa-fw"></i>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th><?php echo e(__('report.total_wastage'), false); ?>:</th>
                    <td>
                        <span class="total_wastage">
                            <i class="fas fa-sync fa-spin fa-fw"></i>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th><?php echo e(__('report.total_damage'), false); ?>:</th>
                    <td>
                        <span class="total_damage">
                            <i class="fas fa-sync fa-spin fa-fw"></i>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th><?php echo e(__('report.total_shortage'), false); ?>:</th>
                    <td>
                        <span class="total_shortage">
                            <i class="fas fa-sync fa-spin fa-fw"></i>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th><?php echo e(__('report.total_stock_adjustment'), false); ?>:</th>
                    <td>
                        <span class="total_amount">
                            <i class="fas fa-sync fa-spin fa-fw"></i>
                        </span>
                    </td>
                </tr>
            </table>
            <?php echo $__env->renderComponent(); ?>
        </div>

        <div class="col-sm-6">
            <?php $__env->startComponent('components.widget'); ?>
            <table class="table no-border">
                <tr>
                    <th><?php echo e(__('report.total_recovered'), false); ?>:</th>
                    <td>
                        <span class="total_recovered">
                            <i class="fas fa-sync fa-spin fa-fw"></i>
                        </span>
                    </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
            </table>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12">
            <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' =>
            __('stock_adjustment.stock_adjustments')]); ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="stock_adjustment_report_table">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('messages.date'); ?></th>
                            <th><?php echo app('translator')->get('purchase.ref_no'); ?></th>
                            <th><?php echo app('translator')->get('business.location'); ?></th>
                            <th><?php echo app('translator')->get('stock_adjustment.adjustment_type'); ?></th>
                            <th><?php echo app('translator')->get('stock_adjustment.total_amount'); ?></th>
                            <th><?php echo app('translator')->get('stock_adjustment.total_amount_recovered'); ?></th>
                            <th><?php echo app('translator')->get('stock_adjustment.reason_for_stock_adjustment'); ?></th>
                            <th><?php echo app('translator')->get('lang_v1.added_by'); ?></th>
                        </tr>
                    </thead>
                </table>
            </div>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>


</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/stock_adjustment.js?v=' . $asset_v), false); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneltech/panel/resources/views/report/stock_adjustment_report.blade.php ENDPATH**/ ?>