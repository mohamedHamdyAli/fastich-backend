<div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title hide" id="modalTitle"><?php echo e($recipe->variation->full_name, false); ?></h4>

    </div>
    <div class="modal-body">

        <div class="row">
            <div class="col-md-12">
                <table class="table table-hover">
                    <thead class="thead-light">
                        <tr class="bg-gray">
                            <th><?php echo app('translator')->get('manufacturing::lang.ingredient'); ?></th>
                            <th><?php echo app('translator')->get('lang_v1.quantity'); ?></th>
                            <th><?php echo app('translator')->get('lang_v1.price'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $ingredient_groups = [];
                        $ingredient_total_price = 0;
                        ?>
                        <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $ingredient_price =
                        $ingredient['quantity']*$ingredient['default_purchase_price']*$ingredient['multiplier'];
                        $ingredient_total_price += $ingredient_price;
                        ?>
                        <?php if(empty($ingredient['mfg_ingredient_group_id'])): ?>
                        <tr>
                            <td>
                                <?php echo e($ingredient['full_name'], false); ?>

                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="false"><?php echo e(number_format($ingredient['quantity'], config('constants.quantity_precision', 2), session('currency')['decimal_separator'], session('currency')['thousand_separator']), false); ?></span>
                                <?php echo e($ingredient['unit'], false); ?>

                            </td>
                            <td><span ><?php echo e($ingredient_price, false); ?></span>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="2" class="text-right">
                                <strong><?php echo app('translator')->get('manufacturing::lang.ingredients_cost'); ?></strong></td>
                            <td><span ><?php echo e($ingredient_total_price, false); ?></span></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/paneltech/panel/resources/views/product/recipe/show.blade.php ENDPATH**/ ?>