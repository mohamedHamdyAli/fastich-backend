<?php if(empty($only) || in_array('report_list_filter_location_id', $only)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('report_list_filter_location_id', __('purchase.business_location') . ':'); ?>


        <?php echo Form::select('report_list_filter_location_id', $business_locations, null, ['class' => 'form-control select2',
        'style' => 'width:100%', 'placeholder' => __('lang_v1.all') ]); ?>

    </div>
</div>
<?php endif; ?>

<?php if(empty($only) || in_array('report_list_filter_payment_status', $only)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('report_list_filter_payment_status', __('purchase.payment_status') . ':'); ?>

        <?php echo Form::select('report_list_filter_payment_status', ['paid' => __('lang_v1.paid'),
        'returned' => __('lang_v1.returned'), 'partial' => __('lang_v1.partial')],
        null, ['class' => 'form-control
        select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); ?>

    </div>
</div>
<?php endif; ?>

<?php if(empty($only) || in_array('report_list_filter_payment_method', $only)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('report_list_filter_payment_method', __('purchase.payment_method') . ':'); ?>

        <?php echo Form::select('report_list_filter_payment_method', $payment_method_filter, null, ['class' => 'form-control
        select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); ?>

    </div>
</div>
<?php endif; ?>
<?php if(empty($only) || in_array('report_list_filter_client_app', $only)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('report_list_filter_client_app', __('client_app.client_app_name') . ':'); ?>

        <?php echo Form::select('report_list_filter_client_app', $client_app_filter, null, ['class' => 'form-control
        select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); ?>

    </div>
</div>
<?php endif; ?>
<?php if(empty($only) || in_array('report_list_filter_customer_id', $only)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('report_list_filter_customer_id', __('contact.customer') . ':'); ?>

        <?php echo Form::select('report_list_filter_customer_id', $customers, null, ['class' => 'form-control select2', 'style'
        => 'width:100%', 'placeholder' => __('lang_v1.all')]); ?>

    </div>
</div>
<?php endif; ?>
<?php if(empty($only) || in_array('report_list_filter_date_range', $only)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('report_list_filter_date_range', __('report.date_range') . ':'); ?>

        <?php echo Form::text('report_list_filter_date_range', null, ['placeholder' => __('lang_v1.select_a_date_range'), 'class'
        => 'form-control', 'readonly']); ?>

    </div>
</div>
<?php endif; ?>
<?php if(empty($only) || in_array('report_start_time', $only)): ?>
<div class="col-md-3 form-group">
    <?php echo Form::label('report_start_time', __('lang_v1.time_range') . ':'); ?>

    <?php
    $startDay = Carbon::now()->startOfDay();
    $endDay = $startDay->copy()->endOfDay();
    ?>
    <div class="input-group">
        <?php echo Form::text('start_time', \Carbon::createFromTimestamp(strtotime($startDay))->format('H:i'), ['class' =>
        'form-control width-50', 'id' => 'report_start_time']); ?>

        <?php echo Form::text('end_time', \Carbon::createFromTimestamp(strtotime($endDay))->format('H:i'), ['class' => 'form-control width-50 ', 'id' =>
        'report_end_time']); ?>

    </div>
</div>
<?php endif; ?>
<?php if((empty($only) || in_array('report_list_filter_created_by', $only)) && !empty($sales_representative)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('report_list_filter_created_by', __('report.user') . ':'); ?>

        <?php echo Form::select('report_list_filter_created_by', $sales_representative, null, ['class' => 'form-control select2', 'style' =>
        'width:100%']); ?>

    </div>
</div>
<?php endif; ?>
<?php /**PATH /home/paneltech/panel/resources/views/report/partials/report_list_filters.blade.php ENDPATH**/ ?>