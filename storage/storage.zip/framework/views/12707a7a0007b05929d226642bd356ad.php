<!-- business information here -->

<div class="row">
    <!-- Logo & Header -->
    <div class="col-xs-offset-1 col-xs-10 col-xs-offset-1" style="border: 1px solid black;">
        <div class="col-xs-5 text-justify" style="margin-top: 5px;">
            <p>
                <?php if(!empty($receipt_details->business_name)): ?>
                <strong>
                    <?php echo e($receipt_details->business_name, false); ?>

                </strong>
                <?php endif; ?>

                <?php if(!empty($receipt_details->location_name)): ?>
                <strong>
                    <br /><?php echo e($receipt_details->location_name, false); ?>

                </strong>
                <?php endif; ?>
                <?php if(!empty($receipt_details->location_city)): ?>
                <strong>
                    <br /><?php echo e($receipt_details->location_city, false); ?>

                </strong>
                <?php endif; ?>
                <?php if(!empty($receipt_details->business_tax_number_1)): ?>
                <strong style="font-size: small;">
                    <br /><b> <?php echo e($receipt_details->business_tax_label_1, false); ?>:</b>
                    <?php echo e($receipt_details->business_tax_number_1, false); ?>

                </strong>
                <?php endif; ?>
                <?php if(!empty($receipt_details->business_tax_number_2)): ?>
                <strong style="font-size: small;">
                    <br /><b><?php echo e($receipt_details->business_tax_label_2, false); ?>:</b>
                    <?php echo e($receipt_details->business_tax_number_2, false); ?>

                </strong>
                <?php endif; ?>
            </p>
        </div>
        <div class="col-xs-3 text-center" style="margin-top: 20px;">
            <p>
                <?php if(!empty($receipt_details->logo)): ?>
                <img style="width: 100px;height: 100px" alt="logo" src="<?php echo e($receipt_details->logo, false); ?>"
                    class="img img-responsive center-block">
                <?php endif; ?>
            </p>
        </div>
        <div class="col-xs-4 text-justify">
            <?php if(!empty($receipt_details->invoice_heading)): ?>
            <h4 style="font-weight: 900;">
                <?php echo $receipt_details->invoice_heading; ?>

            </h4>
            <?php endif; ?>
            <p style="float: right;">
                <?php if(!empty($receipt_details->qrcode)): ?>
                <img width="100px" class="center-block" src="<?php echo e($receipt_details->qrcode, false); ?>" alt="QR Code" />
                <?php endif; ?>
            </p>
        </div>

    </div>


    <!-- Header text -->
    <?php if(!empty($receipt_details->header_text)): ?>
    <div class="col-xs-12" style="margin-top: 10px;">
        <?php echo $receipt_details->header_text; ?>

        <p style="text-align: center;">
            <strong>
                <?php if(!empty($receipt_details->sub_heading_line1)): ?>
                <?php echo e($receipt_details->sub_heading_line1, false); ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->sub_heading_line2)): ?>
                <br><?php echo e($receipt_details->sub_heading_line2, false); ?>

                <?php endif; ?>
            </strong>
            <strong>
                <?php if(!empty($receipt_details->sub_heading_line3)): ?>
                <br><?php echo e($receipt_details->sub_heading_line3, false); ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->sub_heading_line4)): ?>
                <br><?php echo e($receipt_details->sub_heading_line4, false); ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->sub_heading_line5)): ?>
                <br><?php echo e($receipt_details->sub_heading_line5, false); ?>

                <?php endif; ?>
            </strong>
        </p>
    </div>
    <?php endif; ?>

    <!-- business information here -->
    <div class="col-xs-12" style="margin-top: 10px;">
        <div class="col-xs-8 text-left">
            <!-- Address -->
            <p>
                <!-- customer info -->
                <?php if(!empty($receipt_details->customer_name)): ?>
                <b><?php echo e($receipt_details->customer_label, false); ?>:</b>
                <?php echo e($receipt_details->customer_name, false); ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->customer_city)): ?>
                | <?php echo $receipt_details->customer_city; ?>

                <?php endif; ?>
                <!--  <?php if(!empty($receipt_details->customer_mobile)): ?>
                |<?php echo $receipt_details->customer_mobile; ?>

                <?php endif; ?> -->
                <?php if(!empty($receipt_details->supplier_business_name)): ?>
                <br /><b> <?php echo app('translator')->get('business.business_name' ); ?>:</b> <?php echo e($receipt_details->supplier_business_name, false); ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->customer_tax_label)): ?>
                <br />
                <b><?php echo e($receipt_details->customer_tax_label, false); ?>:</b> <?php echo e($receipt_details->customer_tax_number, false); ?>

                <?php endif; ?>

                <?php if(!empty($receipt_details->client_id_label)): ?>
                <br />
                <b><?php echo e($receipt_details->client_id_label, false); ?></b> <?php echo e($receipt_details->client_id, false); ?>

                <?php endif; ?>

                <?php if(!empty($receipt_details->customer_custom_fields)): ?>
                <br /><?php echo $receipt_details->customer_custom_fields; ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->sales_person_label)): ?>
                <br />
                <b><?php echo e($receipt_details->sales_person_label, false); ?></b> <?php echo e($receipt_details->sales_person, false); ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->customer_rp_label)): ?>
                <br />
                <strong><?php echo e($receipt_details->customer_rp_label, false); ?></strong> <?php echo e($receipt_details->customer_total_rp, false); ?>

                <?php endif; ?>
            </p>
            <p>

                <?php if(!empty($receipt_details->contact)): ?>
                <br /><?php echo e($receipt_details->contact, false); ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->contact) && !empty($receipt_details->website)): ?>
                ,
                <?php endif; ?>
                <?php if(!empty($receipt_details->website)): ?>
                <?php echo e($receipt_details->website, false); ?>

                <?php endif; ?>
                <?php if(!empty($receipt_details->location_custom_fields)): ?>
                <br><?php echo e($receipt_details->location_custom_fields, false); ?>

                <?php endif; ?>
            </p>
            <p>
                <?php if(!empty($receipt_details->tax_info1)): ?>
                <b><?php echo e($receipt_details->tax_label1, false); ?></b> <?php echo e($receipt_details->tax_info1, false); ?>

                <?php endif; ?>

                <?php if(!empty($receipt_details->tax_info2)): ?>
                <b><?php echo e($receipt_details->tax_label2, false); ?></b> <?php echo e($receipt_details->tax_info2, false); ?>

                <?php endif; ?>
            </p>
        </div>

        <div class="col-xs-4 text-right">
            <p style=" font-size: 20px;">
                <?php if(!empty($receipt_details->invoice_no_prefix)): ?>
                <b><?php echo $receipt_details->invoice_no_prefix; ?>:
                    <?php echo $receipt_details->invoice_no; ?>

                </b>
                <?php endif; ?>
            </p>
            <b><?php echo e($receipt_details->date_label, false); ?> <?php echo e($receipt_details->invoice_date, false); ?> </b>

            <?php if(!empty($receipt_details->due_date_label)): ?>
            <br><b><?php echo e($receipt_details->due_date_label, false); ?></b> <?php echo e($receipt_details->due_date ?? '', false); ?>

            <?php endif; ?>
        </div>




    </div>
</div>
<div class="row hide">
    <div class="col-xs-12">
        <p style="width: 100% !important hide" class="word-wrap">
            <span class="pull-left text-left word-wrap ">
                <?php if(!empty($receipt_details->types_of_service)): ?>
                <br />
                <span class="pull-left text-left">
                    <strong><?php echo $receipt_details->types_of_service_label; ?>:</strong>
                    <?php echo e($receipt_details->types_of_service, false); ?>


                    <?php if(!empty($receipt_details->types_of_service_custom_fields)): ?>
                    <?php $__currentLoopData = $receipt_details->types_of_service_custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <br><strong><?php echo e($key, false); ?>: </strong> <?php echo e($value, false); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </span>
                <?php endif; ?>

                <!-- Table information-->
                <?php if(!empty($receipt_details->table_label) || !empty($receipt_details->table)): ?>
                <br />
                <span class="pull-left text-left">
                    <?php if(!empty($receipt_details->table_label)): ?>
                    <b><?php echo $receipt_details->table_label; ?></b>
                    <?php endif; ?>
                    <?php echo e($receipt_details->table, false); ?>

                </span>
                <?php endif; ?>
            </span>
            <span class="pull-right text-left">
                <?php if(!empty($receipt_details->brand_label) || !empty($receipt_details->repair_brand)): ?>
                <br>
                <?php if(!empty($receipt_details->brand_label)): ?>
                <b><?php echo $receipt_details->brand_label; ?></b>
                <?php endif; ?>
                <?php echo e($receipt_details->repair_brand, false); ?>

                <?php endif; ?>


                <?php if(!empty($receipt_details->device_label) || !empty($receipt_details->repair_device)): ?>
                <br>
                <?php if(!empty($receipt_details->device_label)): ?>
                <b><?php echo $receipt_details->device_label; ?></b>
                <?php endif; ?>
                <?php echo e($receipt_details->repair_device, false); ?>

                <?php endif; ?>

                <?php if(!empty($receipt_details->model_no_label) || !empty($receipt_details->repair_model_no)): ?>
                <br>
                <?php if(!empty($receipt_details->model_no_label)): ?>
                <b><?php echo $receipt_details->model_no_label; ?></b>
                <?php endif; ?>
                <?php echo e($receipt_details->repair_model_no, false); ?>

                <?php endif; ?>

                <?php if(!empty($receipt_details->serial_no_label) || !empty($receipt_details->repair_serial_no)): ?>
                <br>
                <?php if(!empty($receipt_details->serial_no_label)): ?>
                <b><?php echo $receipt_details->serial_no_label; ?></b>
                <?php endif; ?>
                <?php echo e($receipt_details->repair_serial_no, false); ?><br>
                <?php endif; ?>
                <?php if(!empty($receipt_details->repair_status_label) || !empty($receipt_details->repair_status)): ?>
                <?php if(!empty($receipt_details->repair_status_label)): ?>
                <b><?php echo $receipt_details->repair_status_label; ?></b>
                <?php endif; ?>
                <?php echo e($receipt_details->repair_status, false); ?><br>
                <?php endif; ?>

                <?php if(!empty($receipt_details->repair_warranty_label) || !empty($receipt_details->repair_warranty)): ?>
                <?php if(!empty($receipt_details->repair_warranty_label)): ?>
                <b><?php echo $receipt_details->repair_warranty_label; ?></b>
                <?php endif; ?>
                <?php echo e($receipt_details->repair_warranty, false); ?>

                <br>
                <?php endif; ?>

                <!-- Waiter info -->
                <?php if(!empty($receipt_details->service_staff_label) || !empty($receipt_details->service_staff)): ?>
                <br />
                <?php if(!empty($receipt_details->service_staff_label)): ?>
                <b><?php echo $receipt_details->service_staff_label; ?></b>
                <?php endif; ?>
                <?php echo e($receipt_details->service_staff, false); ?>

                <?php endif; ?>
            </span>
        </p>
    </div>
</div>

<div class="row hide">
    <?php if ($__env->exists('sale_pos.receipts.partial.common_repair_invoice')) echo $__env->make('sale_pos.receipts.partial.common_repair_invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="row">
    <div class="col-xs-12">
        <br />
        <table class="table table-responsive table-slim table-bordered-print">
            <thead>
                <tr>
                    <th class="text-right" width="40%"><?php echo e($receipt_details->table_product_label, false); ?></th>
                    <th class="text-right" width="20%"><?php echo e($receipt_details->table_qty_label, false); ?></th>
                    <th class="text-right" width="20%"><?php echo e($receipt_details->table_unit_price_label, false); ?></th>
                    <th class="text-right" width="20%"><?php echo e($receipt_details->table_subtotal_label, false); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $receipt_details->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-right" style="word-break: break-all;">
                        <?php if(!empty($line['image'])): ?>
                        <img src="<?php echo e($line['image'], false); ?>" alt="Image" width="50" style="float: left; margin-right: 8px;">
                        <?php endif; ?>
                        <?php echo e($line['name'], false); ?>

                        <?php echo e($line['product_variation'], false); ?> <?php echo e($line['variation'], false); ?>

                        <?php if(!empty($line['sub_sku'])): ?>, <?php echo e($line['sub_sku'], false); ?> <?php endif; ?>
                        <?php if(!empty($line['brand'])): ?>,
                        <?php echo e($line['brand'], false); ?> <?php endif; ?>
                        <?php if(!empty($line['cat_code'])): ?>, <?php echo e($line['cat_code'], false); ?><?php endif; ?>
                        <?php if(!empty($line['product_custom_fields'])): ?>, <?php echo e($line['product_custom_fields'], false); ?> <?php endif; ?>
                        <?php if(!empty($line['sell_line_note'])): ?>
                        <br>
                        <small>
                            <?php echo e($line['sell_line_note'], false); ?>

                        </small>
                        <?php endif; ?>
                        <?php if(!empty($line['lot_number'])): ?><br> <?php echo e($line['lot_number_label'], false); ?>: <?php echo e($line['lot_number'], false); ?>

                        <?php endif; ?>
                        <?php if(!empty($line['product_expiry'])): ?>, <?php echo e($line['product_expiry_label'], false); ?>:
                        <?php echo e($line['product_expiry'], false); ?> <?php endif; ?>

                        <?php if(!empty($line['warranty_name'])): ?> <br><small><?php echo e($line['warranty_name'], false); ?> </small><?php endif; ?>
                        <?php if(!empty($line['warranty_exp_date'])): ?> <small>- <?php echo e(\Carbon::createFromTimestamp(strtotime($line['warranty_exp_date']))->format(session('business.date_format')), false); ?>

                        </small><?php endif; ?>
                        <?php if(!empty($line['warranty_description'])): ?> <small>
                            <?php echo e($line['warranty_description'] ?? '', false); ?></small><?php endif; ?>
                    </td>
                    <td class="text-right"><?php echo e($line['quantity'], false); ?> <?php echo e($line['units'], false); ?> </td>
                    <td class="text-right"><?php echo e($line['unit_price'], false); ?></td>
                    <td class="text-right"><?php echo e($line['line_total'], false); ?></td>
                </tr>
                <?php if(!empty($line['modifiers'])): ?>
                <?php $__currentLoopData = $line['modifiers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modifier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($modifier['name'], false); ?> <?php echo e($modifier['variation'], false); ?>

                        <?php if(!empty($modifier['sub_sku'])): ?>, <?php echo e($modifier['sub_sku'], false); ?> <?php endif; ?>
                        <?php if(!empty($modifier['cat_code'])): ?>, <?php echo e($modifier['cat_code'], false); ?><?php endif; ?>
                        <?php if(!empty($modifier['sell_line_note'])): ?>(<?php echo e($modifier['sell_line_note'], false); ?>) <?php endif; ?>
                    </td>
                    <td class="text-right"><?php echo e($modifier['quantity'], false); ?> <?php echo e($modifier['units'], false); ?> </td>
                    <td class="text-right"><?php echo e($modifier['unit_price_inc_tax'], false); ?></td>
                    <td class="text-right"><?php echo e($modifier['line_total'], false); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">&nbsp;</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="row">
    <hr />
    <div class="col-xs-6">
        <table class="table table-slim table-bordered-print">
            <?php if(!empty($receipt_details->payments)): ?>
            <?php $__currentLoopData = $receipt_details->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="text-justify"><?php echo e($payment['method'], false); ?>:</th>
                <th class="text-right"><?php echo e($payment['amount'], false); ?></th>
                <!--  <td><?php echo e($payment['date'], false); ?></td> -->
            </tr>
            <?php if(!empty($payment['payment_note'])): ?>
            <tr>
                <th class="text-justify"><?php echo app('translator')->get( 'lang_v1.payment_note' ); ?>:</th>
                <th class="text-right"><?php echo e($payment['payment_note'], false); ?></th>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!-- Total Paid-->
            <?php if(!empty($receipt_details->total_paid)): ?>
            <tr>
                <th class="text-justify">
                    <?php echo $receipt_details->total_paid_label; ?>:
                </th>
                <th class="text-right">
                    <?php echo e($receipt_details->total_paid, false); ?>

                </th>
            </tr>
            <?php endif; ?>
            <!-- Total Due-->
            <?php if(!empty($receipt_details->total_due)): ?>
            <tr>
                <th class="text-justify">
                    <?php echo $receipt_details->total_due_label; ?>:
                </th>
                <th class="text-right">
                    <?php echo e($receipt_details->total_due, false); ?>

                </th>
            </tr>
            <?php endif; ?>

            <?php if(!empty($receipt_details->all_due)): ?>
            <tr>
                <th class="text-justify">
                    <?php echo $receipt_details->all_bal_label; ?>:
                </th>
                <td class="text-right">
                    <?php echo e($receipt_details->all_due, false); ?>

                </td>
            </tr>
            <?php endif; ?>
        </table>
    </div>

    <div class="col-xs-6">
        <table class="table table-responsive table-slim table-bordered-print">
            <tbody>
                <?php if(!empty($receipt_details->total_quantity_label)): ?>
                <tr class="color-555">
                    <th class="text-justify" style="width:70%">
                        <?php echo $receipt_details->total_quantity_label; ?>:
                    </th>
                    <th class="text-right">
                        <?php echo e($receipt_details->total_quantity, false); ?>

                    </th>
                </tr>
                <?php endif; ?>
                <tr>
                    <th class="text-justify" style="width:70%">
                        <?php echo $receipt_details->subtotal_label; ?>

                    </th>
                    <th class="text-right">
                        <?php echo e($receipt_details->subtotal, false); ?>

                    </th>
                </tr>
                <?php if(!empty($receipt_details->total_exempt_uf)): ?>
                <tr>
                    <th class="text-justify" style="width:70%">
                        <?php echo app('translator')->get('lang_v1.exempt'); ?>
                    </th>
                    <th class="text-right">
                        <?php echo e($receipt_details->total_exempt, false); ?>

                    </th>
                </tr>
                <?php endif; ?>
                <!-- Shipping Charges -->
                <?php if(!empty($receipt_details->shipping_charges)): ?>
                <tr>
                    <th class="text-justify" style="width:70%">
                        <?php echo $receipt_details->shipping_charges_label; ?>

                    </th>
                    <th class="text-right">
                        <?php echo e($receipt_details->shipping_charges, false); ?>

                    </th>
                </tr>
                <?php endif; ?>

                <?php if(!empty($receipt_details->packing_charge)): ?>
                <tr>
                    <th class="text-justify" style="width:70%">
                        <?php echo $receipt_details->packing_charge_label; ?>

                    </th>
                    <th class="text-right">
                        <?php echo e($receipt_details->packing_charge, false); ?>

                    </th>
                </tr>
                <?php endif; ?>

                <!-- Discount -->
                <?php if( !empty($receipt_details->discount) ): ?>
                <tr>
                    <th class="text-justify">
                        <?php echo $receipt_details->discount_label; ?>

                    </th>

                    <th class="text-right">
                        (-) <?php echo e($receipt_details->discount, false); ?>

                    </th>
                </tr>
                <?php endif; ?>

                <?php if( !empty($receipt_details->reward_point_label) ): ?>
                <tr>
                    <th class="text-justify">
                        <?php echo $receipt_details->reward_point_label; ?>

                    </th>

                    <th class="text-right">
                        (-) <?php echo e($receipt_details->reward_point_amount, false); ?>

                    </th>
                </tr>
                <?php endif; ?>

                <!-- Tax -->
                <?php if( !empty($receipt_details->tax) ): ?>
                    <tr>
                        <th class="text-justify">
                            <?php echo $receipt_details->tax_label; ?>

                        </th>
                        <th class="text-right">
                            (+) <?php echo e($receipt_details->tax, false); ?>

                        </th>
                    </tr>
                <?php else: ?>
                    <tr>
                        <th class="text-justify">
                            <?php echo $receipt_details->order_tax_label; ?>

                        </th>
                        <th class="text-right">
                            (+) <?php echo e($receipt_details->total_transaction_tax, false); ?>

                        </th>
                    </tr>
                <?php endif; ?>
                <?php if( $receipt_details->round_off_amount > 0): ?>
                <tr>
                    <th class="text-justify">
                        <?php echo $receipt_details->round_off_label; ?>

                    </th>
                    <th class="text-right">
                        <?php echo e($receipt_details->round_off, false); ?>

                    </th>
                </tr>
                <?php endif; ?>

                <!-- Total -->
                <tr>
                    <th class="text-justify total_label">
                        <?php echo $receipt_details->total_label; ?>

                    </th>
                    <th class="text-right total">
                        <?php echo e($receipt_details->total, false); ?>

                        <?php if(!empty($receipt_details->total_in_words)): ?>
                        <br>
                        <small>(<?php echo e($receipt_details->total_in_words, false); ?>)</small>
                        <?php endif; ?>
                    </th>
                </tr>
            </tbody>
        </table>

    </div>
    <?php if($receipt_details->additional_notes): ?>
    <div class="col-xs-12">
        <p class="text-center"> <label> <?php echo app('translator')->get( 'sale.sell_note' ); ?>:</label> <?php echo nl2br($receipt_details->additional_notes); ?></p>
    </div>
    <?php endif; ?>
</div>

<?php if($receipt_details->show_barcode): ?>
<div class="row">
    <div class="col-xs-12">
    </div>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-xs-12">
        <div class="col-xs-4">
            <table>
                <thead>
                    <tr>
                        <th colspan="2" class="text-justify">
                            <h3><?php echo app('translator')->get('business.buyer'); ?></h3>
                        </th>

                    </tr>
                </thead>
                <tr>
                    <th class="text-justify"> <label><?php echo app('translator')->get('business.name'); ?> </th>
                    <th class="text-right">:________________</th>
                </tr>
                <tr>
                    <th class="text-justify"> <label><?php echo app('translator')->get('business.signature'); ?> </th>
                    <th class="text-right">:________________</th>
                </tr>
            </table>
        </div>
        <div class="col-xs-4">
            
            <img width="150px" class="center-block" src="<?php echo e($receipt_details->qrcode, false); ?>" alt="QR Code" />
        </div>
        <div class="col-xs-4">
            <table>
                <thead>
                    <tr>
                        <th colspan="2" class="text-justify">
                            <h3><?php echo app('translator')->get('business.seller'); ?></h3>
                        </th>

                    </tr>
                </thead>
                <tr>
                    <th class="text-justify"> <label><?php echo app('translator')->get('business.name'); ?> </th>
                    <th class="text-right">:________________</th>
                </tr>
                <tr>
                    <th class="text-justify"> <label><?php echo app('translator')->get('business.signature'); ?> </th>
                    <th class="text-right">:________________</th>
                </tr>
            </table>
        </div>
    </div>
</div>

<?php if(!empty($receipt_details->footer_text)): ?>
<div class="row">
    <div class="col-xs-12">
        <?php echo $receipt_details->footer_text; ?>

    </div>
</div>
<?php endif; ?><?php /**PATH /home/paneltech/panel/resources/views/sale_pos/receipts/classic.blade.php ENDPATH**/ ?>