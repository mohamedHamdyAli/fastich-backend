<div class="modal-dialog modal-lg product-modifier-modal" role="document">
    <div class="modal-content">

        <?php echo Form::open(['url' => action('Restaurant\ModifierSetsController@store'), 'method' => 'post', 'id' => 'table_add_form' ]); ?>


        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><?php echo app('translator')->get( 'restaurant.add_modifier' ); ?></h4>
        </div>

        <div class="modal-body">
            <div class="row">

                <div class="col-sm-12">
                    <div class="form-group">
                        <?php echo Form::label('name', __( 'restaurant.modifier_set' ) . ':*'); ?>

                        <?php echo Form::text('name', null, ['class' => 'form-control', 'required', 'placeholder' => __( 'lang_v1.name' ) ]); ?>

                    </div>
                </div>

                <div class="col-sm-12">
                    <h4><?php echo app('translator')->get( 'restaurant.modifiers' ); ?></h4>
                </div>


                <div class="col-sm-12">
                    <table class="table table-condensed" id="add-modifier-table">
                        <thead>
                        <tr>
                            <th><?php echo app('translator')->get( 'restaurant.modifier'); ?></th>
                            <th>
                                <?php echo app('translator')->get( 'lang_v1.price'); ?>

                                <?php
                                    $html = '<tr><td>
                                          <div class="form-group">
                                            <input type="text" name="modifier_name[]" 
                                            class="form-control" 
                                            placeholder="' . __( 'lang_v1.name' ) . '" required>
                                          </div>
                                        </td>
                                        <td>
                                          <div class="form-group">
                                            <input type="text" name="modifier_price[]" class="form-control input_number" 
                                            placeholder="' . __( 'lang_v1.price' ) . '" required>
                                          </div>
                                        </td>
                                        <td>
                                          <div class="form-group">
                                              <select name="modifier_tax[]" class="form-control"  placeholder="Please Select">
                                                
                                              </select>
                                          </div>
                                        </td>
                                        <td>
                                          <div class="form-group">
                                            <select name="modifier_tax_type[]" class="form-control">
                                                <option></option>
                                            </select>
                                          </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input type="text" name="modifier_price_inc_tax[]" class="form-control" required />
                                            </div>
                                        </td>
                                        ';
                
                                    $html_other_row = $html . '<td>
                                            <button class="btn btn-danger btn-xs pull-right remove-modifier-row" type="button"><i class="fa fa-minus"></i></button>
                                          </td>
                                        </tr>';
                
                                    $html_first_row = $html . "<td>
                                            <button class='btn btn-primary btn-xs pull-right add-modifier-row' type='button'
                                            data-html='{{ $html_other_row }}'>
                                            <i class='fa fa-plus'></i></button>
                                          </td>
                                        </tr>";

                                ?>


                            </th>
                            <th><?php echo app('translator')->get( 'restaurant.tax'); ?></th>
                            <th><?php echo app('translator')->get( 'restaurant.tax_type'); ?></th>
                            <th><?php echo app('translator')->get( 'restaurant.price_inc_tax'); ?></th>
                            <th>&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>
                                <div class="form-group">
                                    <input type="text" name="modifier_name[]"
                                           class="form-control"
                                           placeholder="<?php echo e(__( 'lang_v1.name' ), false); ?>" required>
                                </div>
                            </td>
                            <td>
                                <div class="form-group">
                                    <input type="text" name="modifier_price[]"
                                           class="form-control input_number modifier-price"
                                           placeholder="<?php echo e(__( 'lang_v1.price' ), false); ?>" required>
                                </div>
                            </td>
                            <td>
                                <div class="form-group">
                                    <select name="modifier_tax[]" class="form-control select2 modifier-tax">
                                        <option value="">Please Select</option>
                                        <?php $__currentLoopData = $taxRates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxRate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option data-amount="<?php echo e($taxRate['amount'], false); ?>"
                                                    value="<?php echo e($taxRate['id'], false); ?>"><?php echo e($taxRate['name'], false); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </td>
                            <td>
                                <div class="form-group">
                                    <?php echo Form::select('modifier_tax_type[]', ['inclusive' => __('product.inclusive'), 'exclusive' => __('product.exclusive')], 'exclusive',['class' => 'form-control select2 modifier-tax-type', 'required']); ?>

                                </div>
                            </td>
                            <td>
                                <div class="form-group">
                                    <input type="text" name="modifier_price_inc_tax[]" readonly
                                           class="form-control input_number modifier-price-inc-tax"
                                           required/>
                                </div>
                            </td>
                            <td>
                                <button class='btn btn-primary btn-xs pull-right add-modifier-row' type='button'>
                                    <i class='fa fa-plus'></i></button>
                            </td>
                            <td>
                                <button class="btn btn-danger btn-xs pull-right remove-modifier-row" type="button"><i
                                            class="fa fa-minus"></i></button>
                            </td>
                        </tr>
                        
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

        <div class="modal-footer">
            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get( 'messages.save' ); ?></button>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->get( 'messages.close' ); ?></button>
        </div>

        <?php echo Form::close(); ?>


    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
<?php /**PATH /home/paneltech/panel/resources/views/restaurant/modifier_sets/create.blade.php ENDPATH**/ ?>