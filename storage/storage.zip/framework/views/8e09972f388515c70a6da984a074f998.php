<div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">

        <div class="modal-header">
            <button type="button" class="close no-print" data-dismiss="modal" aria-label="Close"><span
                    aria-hidden="true">&times;</span></button>
            <h3 class="modal-title"><?php echo app('translator')->get( 'cash_register.register_details' ); ?> (
                <?php echo e(\Carbon::createFromFormat('Y-m-d H:i:s', $register_details->open_time)->format('jS M, Y h:i A'), false); ?> -
                <?php echo e(\Carbon::createFromFormat('Y-m-d H:i:s', $close_time)->format('jS M, Y h:i A'), false); ?> )</h3>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-sm-12">
                    <table class="table">
                        <tr>
                            <th colSpan="2" style="text-align:center;">
                                <?php echo app('translator')->get('lang_v1.payments'); ?>:
                            </th>
                        </tr>
                        <tr>
                            <td>
                                <?php echo app('translator')->get('cash_register.cash_payment'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_cash, false); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <?php echo app('translator')->get('cash_register.card_payment'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_card, false); ?></span>
                            </td>
                        </tr>
                        <?php if(!empty($register_details->clientAppArray)): ?>
                        <?php $__currentLoopData = $register_details->clientAppArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client_app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($client_app['total_prepaid_value'] != 0): ?>
                        <tr>
                            <td>
                                <?php echo e($client_app['app_prepaid_title'] ? $client_app['app_prepaid_title'] : 0.00, false); ?>

                            </td>
                            <td>
                                <span className="display_currency"
                                    data-currency_symbol="true"><?php echo e($client_app['total_prepaid_value'] ? $client_app['total_prepaid_value'] : 0.00, false); ?>

                                </span>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if($client_app['total_cash_value'] != 0): ?>
                        <tr>
                            <td>
                                <?php echo e($client_app['app_cash_title'] ? $client_app['app_cash_title'] : 0.00, false); ?>

                            </td>
                            <td>
                                <span className="display_currency"
                                    data-currency_symbol="true"><?php echo e($client_app['total_cash_value'] ? $client_app['total_cash_value'] : 0.00, false); ?>

                                </span>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if($client_app['total_card_value'] != 0): ?>
                        <tr>
                            <td>
                                <?php echo e($client_app['app_card_title'] ? $client_app['app_card_title'] : 0.00, false); ?>

                            </td>
                            <td>
                                <span className="display_currency"
                                    data-currency_symbol="true"><?php echo e($client_app['total_card_value'] ? $client_app['total_card_value'] : 0.00, false); ?>

                                </span>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <tr class="">
                            <th>
                                <?php echo app('translator')->get('lang_v1.total_payment'); ?>:
                            </th>
                            <td>
                                <b>
                                    <span class="display_currency" data-currency_symbol="true">
                                        <?php echo e($register_details->total_payment_new ? $register_details->total_payment_new : 0.00, false); ?>

                                    </span>
                                </b>
                            </td>
                        </tr>
                        <tr class="">
                            <th>
                                <?php echo app('translator')->get('cash_register.total_refund'); ?>:
                            </th>
                            <td>
                                <b>
                                    <span class="display_currency" data-currency_symbol="true">
                                        <?php echo e($register_details->total_refund_cash_new ? ($register_details->total_refund_cash_new) : 0.00, false); ?>

                                    </span>
                                </b>
                            </td>
                        </tr>
                        <tr class="">
                            <th>
                                <?php echo app('translator')->get('lang_v1.net_payment'); ?>:
                            </th>
                            <td>
                                <b>
                                    <span class="display_currency" data-currency_symbol="true">
                                        <?php echo e($register_details->net_payment_new ? ($register_details->net_payment_new) : 0.00, false); ?>

                                    </span>
                                </b>
                            </td>
                        </tr>
                        <!--  Net payments by type -->
                        <tr>
                            <th colSpan="2" style="text-align:center;">
                                <?php echo app('translator')->get('lang_v1.net_payments_by_type'); ?>:
                            </th>
                        </tr>
                        <tr class="">
                            <th>
                                <?php echo app('translator')->get('lang_v1.total_cash'); ?>:
                            </th>
                            <td>
                                <b>
                                    <span class="display_currency" data-currency_symbol="true">
                                        <?php echo e($register_details->all_cash_new ? ($register_details->all_cash_new) : 0.00, false); ?>

                                    </span>
                                </b>
                            </td>
                        </tr>
                        <tr class="">
                            <th>
                                <?php echo app('translator')->get('lang_v1.total_card'); ?>:
                            </th>
                            <td>
                                <b>
                                    <span class="display_currency" data-currency_symbol="true">
                                        <?php echo e($register_details->all_card_new ? ($register_details->all_card_new) : 0.00, false); ?>

                                    </span>
                                </b>
                            </td>
                        </tr>
                        <tr class="">
                            <th>
                                <?php echo app('translator')->get('lang_v1.prepaid_app'); ?>:
                            </th>
                            <td>
                                <b>
                                    <span class="display_currency" data-currency_symbol="true">
                                        <?php echo e($register_details->total_prepaid ? ($register_details->total_prepaid) : 0.00, false); ?>

                                    </span>
                                </b>
                            </td>
                        </tr>
                        <tr class="">
                            <th>
                                <?php echo app('translator')->get('lang_v1.total_discount'); ?>:
                            </th>
                            <td>
                                <b>
                                    <span class="display_currency" data-currency_symbol="true">
                                        <?php echo e($register_details->total_discount ? ($register_details->total_discount) : 0.00, false); ?>

                                    </span>
                                </b>
                            </td>
                        </tr>
                        <!-- Monetary -->
                        <tr>
                            <th colSpan="2" style="text-align:center;">
                                <?php echo app('translator')->get('lang_v1.monetary_custody'); ?>:
                            </th>
                        </tr>
                        <tr class="success">
                            <td>
                                <?php echo app('translator')->get('lang_v1.cash_in_hand'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->cash_in_hand ? ($register_details->cash_in_hand) : 0.00, false); ?></span>
                            </td>
                        </tr>
                        <tr class="success">
                            <td>
                                <?php echo app('translator')->get('lang_v1.total_expense'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_expense ? ($register_details->total_expense) : 0.00, false); ?></span>
                            </td>
                        </tr>
                        <tr class="success">
                            <td>
                                <?php echo app('translator')->get('lang_v1.remainder_cash_in_hand'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->remainder_cash_in_hand ? ($register_details->remainder_cash_in_hand) : 0.00, false); ?></span>
                            </td>
                        </tr>

                        <!-- Cash Details -->
                        <tr>
                            <th colSpan="2" style="text-align:center;">
                                <?php echo app('translator')->get('lang_v1.cash_details'); ?>:
                            </th>
                        </tr>
                        <tr class="info">
                            <td>
                                <?php echo app('translator')->get('lang_v1.cash_in_register'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->all_cash_new ? ($register_details->all_cash_new) : 0.00, false); ?></span>
                            </td>
                        </tr>

                        <tr class="info">
                            <td>
                                <?php echo app('translator')->get('lang_v1.entered_cash_amount'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->input_cash_in_hand ? ($register_details->input_cash_in_hand) : 0.00, false); ?></span>
                            </td>
                        </tr>
                        <tr class="<?php echo e($register_details->cash_overage_shortage_class, false); ?>">
                            <td>
                                <?php echo e($register_details->cash_overage_shortage_label ? ($register_details->cash_overage_shortage_label) : null, false); ?>

                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->cash_overage_shortage ? ($register_details->cash_overage_shortage) : 0.00, false); ?></span>
                            </td>
                        </tr>

                        <!-- Closing Note  -->

                        <tr>
                            <th colSpan="2" style="text-align:center;">
                                <?php echo app('translator')->get('lang_v1.closing_note'); ?>
                            </th>
                        </tr>
                        <tr class="">
                            <td colSpan="2">
                                <p style="text-align: center;"><?php echo e($register_details->closing_note, false); ?></p>
                            </td>
                        </tr>

                        <!-- Hidden  -->
                        <tr class="hide">
                            <th>
                                <?php echo app('translator')->get('lang_v1.credit_sales'); ?>:
                            </th>
                            <td>
                                <b><span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($details['transaction_details']->total_sales - $register_details->total_sale, false); ?></span></b>
                            </td>
                        </tr>
                        <tr class="hide">
                            <th>
                                <?php echo app('translator')->get('cash_register.total_sales'); ?>:
                            </th>
                            <td>
                                <b><span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($details['transaction_details']->total_sales, false); ?></span></b>
                            </td>
                        </tr>
                        <tr class="hide">
                            <td>
                                <?php echo app('translator')->get('cash_register.checque_payment'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_cheque, false); ?></span>
                            </td>
                        </tr>

                        <tr class="hide">
                            <td>
                                <?php echo app('translator')->get('cash_register.bank_transfer'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_bank_transfer, false); ?></span>
                            </td>
                        </tr>
                        <tr class="hide">
                            <td>
                                <?php echo app('translator')->get('lang_v1.advance_payment'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_advance, false); ?></span>
                            </td>
                        </tr>
                        <?php if(array_key_exists('custom_pay_1', $payment_types)): ?>
                        <tr class="hide">
                            <td>
                                <?php echo e($payment_types['custom_pay_1'], false); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_custom_pay_1, false); ?></span>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if(array_key_exists('custom_pay_2', $payment_types)): ?>
                        <tr class="hide">
                            <td>
                                <?php echo e($payment_types['custom_pay_2'], false); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_custom_pay_2, false); ?></span>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if(array_key_exists('custom_pay_3', $payment_types)): ?>
                        <tr class="hide">
                            <td>
                                <?php echo e($payment_types['custom_pay_3'], false); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_custom_pay_3, false); ?></span>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <tr class="hide">
                            <td>
                                <?php echo app('translator')->get('cash_register.other_payments'); ?>:
                            </td>
                            <td>
                                <span class="display_currency"
                                    data-currency_symbol="true"><?php echo e($register_details->total_other, false); ?></span>
                            </td>
                        </tr>
                        <tr class="hide">
                            <th>
                                <?php echo app('translator')->get('cash_register.total_refund'); ?>
                            </th>
                            <td>
                                <b><span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_refund, false); ?></span></b><br>
                                <small>
                                    <?php if($register_details->total_cash_refund != 0): ?>
                                    Cash: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_cash_refund, false); ?></span><br>
                                    <?php endif; ?>
                                    <?php if($register_details->total_cheque_refund != 0): ?>
                                    Cheque: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_cheque_refund, false); ?></span><br>
                                    <?php endif; ?>
                                    <?php if($register_details->total_card_refund != 0): ?>
                                    Card: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_card_refund, false); ?></span><br>
                                    <?php endif; ?>
                                    <?php if($register_details->total_bank_transfer_refund != 0): ?>
                                    Bank Transfer: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_bank_transfer_refund, false); ?></span><br>
                                    <?php endif; ?>
                                    <?php if($register_details->total_advance_refund != 0): ?>
                                    <?php echo app('translator')->get('lang_v1.advance'); ?>: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_advance_refund, false); ?></span><br>
                                    <?php endif; ?>
                                    <?php if(array_key_exists('custom_pay_1', $payment_types) &&
                                    $register_details->total_custom_pay_1_refund != 0): ?>
                                    <?php echo e($payment_types['custom_pay_1'], false); ?>: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_custom_pay_1_refund, false); ?></span>
                                    <?php endif; ?>
                                    <?php if(array_key_exists('custom_pay_2', $payment_types) &&
                                    $register_details->total_custom_pay_2_refund != 0): ?>
                                    <?php echo e($payment_types['custom_pay_2'], false); ?>: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_custom_pay_2_refund, false); ?></span>
                                    <?php endif; ?>
                                    <?php if(array_key_exists('custom_pay_3', $payment_types) &&
                                    $register_details->total_custom_pay_3_refund != 0): ?>
                                    <?php echo e($payment_types['custom_pay_3'], false); ?>: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_custom_pay_3_refund, false); ?></span>
                                    <?php endif; ?>
                                    <?php if($register_details->total_other_refund != 0): ?>
                                    Other: <span class="display_currency"
                                        data-currency_symbol="true"><?php echo e($register_details->total_other_refund, false); ?></span>
                                    <?php endif; ?>
                                </small>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <?php echo $__env->make('cash_register.register_product_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row">
                <div class="col-xs-6">
                    <b><?php echo app('translator')->get('report.user'); ?>:</b> <?php echo e($register_details->user_name, false); ?><br>
                    <b><?php echo app('translator')->get('business.email'); ?>:</b> <?php echo e($register_details->email, false); ?><br>
                    <b><?php echo app('translator')->get('business.business_location'); ?>:</b> <?php echo e($register_details->location_name, false); ?><br>
                </div>
            </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-primary no-print" aria-label="Print"
                onclick="$(this).closest('div.modal').printThis();">
                <i class="fa fa-print"></i> <?php echo app('translator')->get( 'messages.print' ); ?>
            </button>

            <button type="button" class="btn btn-default no-print" data-dismiss="modal"><?php echo app('translator')->get( 'messages.cancel' ); ?>
            </button>
        </div>

    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog --><?php /**PATH /home/paneltech/panel/resources/views/cash_register/register_details.blade.php ENDPATH**/ ?>