<?php echo e($slot, false); ?>

<?php /**PATH /home/paneltech/panel/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>