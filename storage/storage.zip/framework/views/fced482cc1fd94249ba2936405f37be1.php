<?php
// build File
require_once env('PUBLIC_HTML') . 'build/index.html'; ?><?php /**PATH /home/paneltech/panel/resources/views/pos/index.blade.php ENDPATH**/ ?>