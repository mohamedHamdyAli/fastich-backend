[<?php echo e($slot, false); ?>](<?php echo e($url, false); ?>)
<?php /**PATH /home/paneltech/panel/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>